repo: LaBanHSPO/evgamepad
branch: main
path: plans/260824-1506-evening-forex-gold-gamepad

## Last sync

date: 2026-08-27T16:02:35Z

### Updated in this project

- Read all 14 phase specifications and audited every declared UI surface against what is mocked.
- Twenty-three UI mockups built from the phase specifications, on one pan/zoom canvas.
- Repo is planning-complete with no implementation, so nothing was recreated from app source; every screen is grounded in a phase file plus the bound Evening Gamepad Design System.
- `CandleChart.jsx` copied from the design system's HUD kit as the tape stand-in.

## Screen map

| Project screen | Repo files |
|---|---|
| 1a Trade replay | phase-10-trade-replay.md |
| 1b Voice memo + transcript | phase-08-voice-capture-whisper-and-coach.md |
| 1c Mistake trends & principles | phase-12-daily-journal-cockpit-and-preparation.md |
| 1d GameOverlay sub-pages | phase-03-web-game-and-8bitdo-client-agent.md, phase-07, phase-12, phase-13 |
| 1e Playbook & rule registry editor | phase-07-playbook-and-trade-grading.md |
| 1f Trade detail | phase-12-daily-journal-cockpit-and-preparation.md |
| 1g Reports & export | phase-13-reports-settings-and-data-portability.md |
| 1h Settings, backup, restore, delete-all | phase-13-reports-settings-and-data-portability.md |
| 1i HUD (hot tilt) | phase-03-web-game-and-8bitdo-client-agent.md, phase-09 |
| 1j Deck (stood-down evening) | phase-11-process-score-and-radar-deck.md, phase-06 |
| 2a First run — four gates + boot log | phase-03, phase-08, phase-14 |
| 2b Session close / review processing + post check-in | phase-14, phase-11, phase-03 |
| 2c Degradation matrix — twelve failure states | phase-14, phase-04, phase-08, phase-09, phase-13 |
| 3a Post-trade 3-tap checklist | phase-07 |
| 3b Trade quality — four evidence groups | phase-12 |
| 3c AI desk tab bodies + news rail with citations | phase-04 |
| 3d Volman lens — buildup box, setup label, OQ | phase-04, phase-11 |
| 4a /journal/today — prepare, clocks, sizing, analysis | phase-12 |
| 4b /journal/history — nine filter dimensions | phase-12 |
| 4c /deck Outcome tab | phase-06, phase-12 |
| 5a The evening as one flow — journey contract | phase-14 |
| 6a Keyboard-only — focus trap, announcements, reduced motion | phase-14 |
| 6b Printed report — report-print.css output | phase-13 |

## Not yet mocked

None. Every player-facing surface declared across phases 1–14 has a mockup.
