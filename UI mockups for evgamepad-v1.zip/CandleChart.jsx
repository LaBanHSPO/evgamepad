// Deterministic fake tape — the real app renders Lightweight Charts.
function makeSeries(n, seed) {
  let s = seed, out = [], p = 5089.88;
  const rnd = () => (s = (s * 1103515245 + 12345) % 2147483648) / 2147483648;
  for (let i = 0; i < n; i++) {
    const drift = (rnd() - 0.46) * 2.4;
    const o = p, c = p + drift, h = Math.max(o, c) + rnd() * 1.1, l = Math.min(o, c) - rnd() * 1.1;
    out.push({ o, c, h, l });
    p = c;
  }
  return out;
}

function CandleChart({ height = 300, entry, sl, tp, armed }) {
  const data = React.useMemo(() => makeSeries(64, 7), []);
  const highs = data.map(d => d.h), lows = data.map(d => d.l);
  const hi = Math.max(...highs) + 1.5, lo = Math.min(...lows) - 1.5;
  const y = v => ((hi - v) / (hi - lo)) * height;
  const ema = [];
  data.forEach((d, i) => { ema.push(i === 0 ? d.c : ema[i - 1] + (d.c - ema[i - 1]) * (2 / 21)); });
  const w = 100 / data.length;
  const line = (v, color, label, dash) => v == null ? null : (
    <g key={label}>
      <line x1="0" x2="100" y1={y(v)} y2={y(v)} stroke={color} strokeWidth="0.6" strokeDasharray={dash} vectorEffect="non-scaling-stroke" />
      <text x="99.4" y={y(v) - 3} fill={color} fontFamily="var(--font-mono)" fontSize="7" textAnchor="end" style={{ fontSize: '9px' }}>{label}</text>
    </g>
  );
  return (
    <div style={{ position: 'relative', background: 'var(--ink-02)', border: '1px solid var(--rule)', borderRadius: 'var(--radius-card)', overflow: 'hidden' }}>
      <svg viewBox={'0 0 100 ' + height} preserveAspectRatio="none" width="100%" height={height} style={{ display: 'block' }}>
        {[0.25, 0.5, 0.75].map(f => <line key={f} x1="0" x2="100" y1={height * f} y2={height * f} stroke="var(--rule)" strokeWidth="0.5" vectorEffect="non-scaling-stroke" />)}
        {data.map((d, i) => {
          const up = d.c >= d.o, col = up ? 'var(--long)' : 'var(--short)';
          const x = i * w + w / 2;
          return (
            <g key={i}>
              <line x1={x} x2={x} y1={y(d.h)} y2={y(d.l)} stroke={col} strokeWidth="0.5" vectorEffect="non-scaling-stroke" />
              <rect x={i * w + w * 0.2} width={w * 0.6} y={y(Math.max(d.o, d.c))} height={Math.max(1, Math.abs(y(d.o) - y(d.c)))} fill={up ? 'var(--long)' : 'var(--short)'} opacity="0.85" />
            </g>
          );
        })}
        <polyline points={ema.map((v, i) => (i * w + w / 2) + ',' + y(v)).join(' ')} fill="none" stroke="var(--link)" strokeWidth="1" vectorEffect="non-scaling-stroke" opacity="0.8" />
        {line(entry, 'var(--muted)', 'ENTRY', '3 3')}
        {line(tp, 'var(--long)', 'TP', '3 3')}
        {line(sl, 'var(--short)', 'SL', '3 3')}
      </svg>
      {armed && <div style={{ position: 'absolute', inset: 0, boxShadow: 'inset 0 0 0 1.2px var(--accent)', borderRadius: 'var(--radius-card)', pointerEvents: 'none' }} />}
      <span style={{ position: 'absolute', left: 10, top: 8, fontFamily: 'var(--font-mono)', fontSize: 10, letterSpacing: '0.14em', color: 'var(--soft)', textTransform: 'uppercase' }}>XAUUSD · M5 · 20 EMA</span>
    </div>
  );
}
Object.assign(window, { CandleChart });
