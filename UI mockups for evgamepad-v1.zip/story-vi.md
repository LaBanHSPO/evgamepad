# story-vi.md — kịch bản thuyết trình

Bản dịch của `story.md`. Mười một phút, viết để đọc thành tiếng.
Mã trong ngoặc là nhãn của từng màn hình trên canvas — bấm vào hoặc dùng link `#`.

Thuật ngữ giữ nguyên tiếng Anh: `clutch`, `arm`, `fire`, `flatten`, `stand down`, `tape`, `tilt`,
`playbook`, `adherence`, `selectivity`, `R`, `Process Score`, `demo`. Đây là từ vựng người chơi
dùng hằng ngày trên chính cái pad đó; dịch ra tiếng Việt sẽ làm câu dài hơn mà không rõ hơn.

Trước khi bắt đầu: mở `evgamepad Mockups.dc.html`, zoom ra cho thấy trọn một lượt, và dừng ở `5a`.
Nói câu demo một lần ở đầu và một lần ở cuối. Đừng nhắc ở giữa — làm hai đầu neo thì mạnh hơn
là một lời rào đón lặp lại.

---

## 0 · Mở đầu — 30 giây

> Đây là một game bạn chơi bằng tay cầm.
> Nó giao dịch vàng và forex trên một tài khoản demo.
> Và thứ nó cho điểm không phải là tiền.

Ngừng ở đó. Để câu thứ hai và câu thứ ba tách rời nhau.

> Tất cả những gì sắp thấy là bản kế hoạch, chưa phải sản phẩm đã chạy. Repository hiện có mười bốn
> bản đặc tả phase và chưa có dòng code ứng dụng nào. Hai mươi ba màn hình này là hình dáng của
> các bản đặc tả đó khi được vẽ ra.

Nói điều này sớm. Nó mua cho bạn sự tin cậy cho toàn bộ phần còn lại, và đó đúng là cách sản phẩm
tự đối xử với mình trên từng màn hình.

---

## 1 · Vấn đề nó điều trị — 1 phút

Mở **`1i`** — màn HUD.

> Thử tìm xem sau giá thì con số nào to nhất trên màn này.

Chờ có người tìm ra.

> Là số lần người chơi đã từ chối vào lệnh. Bốn lần `arm` rồi hủy. Màu xanh, và nó đếm lên.
> Lãi lỗ đang mở nằm bên này, tính bằng `R`, còn tiền đô thì nằm sau một cái toggle phải bấm có ý thức.

> Lý do không phải là khiêm tốn. Nhìn tiền trong lúc vị thế còn mở sẽ kéo sự chú ý ra khỏi đúng cái
> quyết định bạn đang thực hiện. Nên giao diện làm cho quyết định to lên và làm cho tiền im đi.

Câu chốt:

> Phần lớn phần mềm giao dịch được xây để bạn nhìn vào tiền. Cái này được xây để bạn nhìn vào
> việc mình đã làm.

---

## 2 · Một đường biên duy nhất — 90 giây

Mở **`5a`** — trọn một buổi tối thành một luồng.

> Sáu chặng, và một quy tắc đúng ở cả sáu.

Chỉ vào làn màu hổ phách.

> Trong hệ thống này đúng một thành phần được phép phê duyệt lệnh: cái gateway. Tay cầm chỉ chuẩn bị
> ý định. AI coach đọc được mọi thứ và không đặt được gì. Voice ghi được memo và không điều hướng
> được menu, nói gì đến `fire`.

> Đó không phải một dòng chính sách trong tài liệu. Cấu hình đặt AI vào đường lệnh thì tiến trình
> thoát ngay khi boot. Tài khoản thật, endpoint thật, và transcription trên cloud cũng vậy.

> Kiểu viền mang nghĩa đó, lấy thẳng từ sơ đồ kiến trúc — viền hổ phách liền nghĩa là được phép
> phê duyệt hoặc chặn lệnh, viền gạch nét nghĩa là không bao giờ được đặt lệnh. Suốt buổi bạn sẽ
> thấy viền gạch nét ở AI desk và ở journal.

Câu chốt:

> Mọi thứ nguy hiểm trong sản phẩm này được ngăn bằng một cái từ chối khởi động,
> không phải bằng việc ai đó nhớ ra.

---

## 3 · Một buổi tối, từ đầu đến cuối — 3 phút

Giữ ở `5a` và đi qua sáu dòng. Chỉ nhảy vào màn hình khi nó đáng để rẽ ngang.

**Lần chạy đầu — `2a`.**
> Dán token, đánh thức pad, xác nhận tài khoản là demo, bật mic nếu muốn.
> Rồi nhìn cột bên phải: boot log kể lại máy đã thực sự tìm thấy gì. Dòng hổ phách đó là kết quả
> dò calibration báo rằng hai nút paddle không hề nhảy, nên chú thích pad sẽ giữ nguyên ở hai
> trigger suốt buổi tối. Đó không phải lỗi. Đó là hệ thống nói cho chính xác.

**Chuẩn bị — `4a`.**
> Bốn đồng hồ phiên theo múi giờ thật, năm câu hỏi readiness, máy tính khối lượng vị thế,
> và phần phân tích bạn tự viết. Một mục readiness được để trống có chủ ý — chưa trả lời không
> giống với trả lời không, và điểm chỉ tính những gì bạn thực sự ghi lại.

**Chơi — `1i`, rồi `1d`.**
> `Clutch` bằng trigger trái, `arm` bằng A hoặc B, xác nhận bằng trigger phải. Luôn luôn hai tay.
> Menu mở một overlay an toàn duy nhất — và mở nó là hủy `arm` cùng khóa mọi lệnh mở mới, vì
> điều hướng và giao dịch không nên là cùng một động tác.

**Checklist — `3a`.**
> Ba lần bấm sau khi đóng lệnh. Một có, một không màu hổ phách, một bỏ qua. Nhìn góc dưới phải:
> lần bỏ qua đã làm mẫu số co lại còn hai trên ba. Câu bị bỏ qua không bị tính điểm không.

**Kết phiên — `2b`.**
> Đây là màn tôi thích nhất. Buổi tối đã xong và ô điểm không chứa con số nào. Nó ghi
> `review processing`, liệt kê hai đầu vào còn đang chờ, và từ chối ghi một điểm số dở dang thành
> điểm cuối. Bấm cái chip thì nó chốt lại thành chín mươi tám.

**Xem lại — `1a`.**
> Phần replay. Kéo lại chính giao dịch của mình trên `tape` bằng stick trái. Và nhìn cái decision
> ledger: dòng thứ hai là một lần `arm` đã hủy, bốn mươi giây trước khi bạn thật sự `fire`.
> `Stand down` nằm trong hồ sơ như một sự kiện, không phải như một khoảng trống.

---

## 4 · Điểm số thưởng cho việc đứng ngoài — 2 phút

Mở **`1j`** — deck của một buổi tối `stand down`.

> Đọc câu tiêu đề trước.

> "Bạn đã ngồi nhìn một cái tape chết ba tiếng và không giao dịch nó."

> Buổi tối đó được một trăm điểm. Một buổi tối giao dịch nhiều và làm tốt được chín mươi tám.

Để nó gây khó chịu một nhịp, rồi giải thích.

> Năm trục, toàn bộ là process: adherence, selectivity, risk discipline, preparation, review.
> Không có win rate. Không có profit factor. Với không lệnh nào, hai trong số các trục đó không có
> mẫu số — nên thay vì cho không điểm, tức là trừng phạt tính kỷ luật, hoặc cho một trăm, tức là
> điểm cho không, chúng bị bỏ ra và trọng số còn lại được chuẩn hóa lại. Radar vẽ chúng thành một
> vòng gạch nét ghi không áp dụng.

> Và đây không phải bữa trưa miễn phí. Chết cứng trong một cái tape tốt được bảy mươi. Giao dịch
> quá tay trong một cái tape chết được sáu mươi lăm. Rụt rè bị coi là lỗi nhỏ hơn liều lĩnh, và đó
> là một quan điểm hệ thống này chủ động nhận.

Câu chốt:

> Không có streak, không có level, không có badge, và không có gì tích lũy qua các phiên.
> Mọi cơ chế có thể tạo áp lực phải giao dịch một buổi tối chết đều bị bỏ đi có chủ ý.

---

## 5 · Niềm tin đến từ đâu — 90 giây

Mở **`2c`** — bảng trung thực.

> Mười hai cách thứ này có thể hỏng, và đúng những chữ nó in ra cho từng cách.

Đọc to hai cái, không hơn.

> Transcription chết: "transcript failed — audio kept". Bản ghi âm vẫn được lưu, vẫn gắn với giao
> dịch, vẫn phát trong replay. Hồ sơ sống sót qua phần phiên âm.

> Dưới năm phiên: "not enough sessions yet". Nó sẽ không in ra một con số tự tin từ ba mẫu.

> Để ý cái không có trên bảng này. Không có gì được vẽ như lỗi đỏ, vì không có cái nào là lỗi của
> người chơi. Hổ phách là thông tin. Xanh là một sự từ chối đang hoạt động đúng thiết kế.

Câu chốt:

> Một công cụ bạn dùng để đánh giá quyết định của mình thì phải trung thực về quyết định của chính nó.
> Không thì bạn đang hiệu chỉnh mình theo một kẻ khéo nói.

---

## 6 · Nó thực sự dùng để làm gì — 1 phút

Mở **`1c`** — mistake trends và principles.

> Tiêu đề là một câu, không phải một điểm số. "Đặt stop trước khi `fire`, không phải sau."
> Bên dưới là số lần nó đã xảy ra, kèm cỡ mẫu, đi từ bảy xuống một.

> Bên phải là các nguyên tắc người chơi tự viết — và mỗi cái mang theo bằng chứng của nó. Cái đầu
> tiên dẫn lại chính voice memo của họ: "Hủy cái này. Tôi `arm` vì nó chạy, không phải vì nó
> vào thế."

> Đó là sản phẩm. Không phải signal. Không phải win rate. Một hồ sơ trung thực đủ để bạn bắt đầu
> tin vào phán đoán của chính mình, kèm bằng chứng để bảo vệ nó.

---

## 7 · Kết — 30 giây

> Chỉ demo. Không phải lời khuyên. Process trước outcome.

> Mục tiêu ghi trong repository là sự tự tin và niềm vui — nâng chất lượng quyết định, không phải
> tiền. Mọi màn hình bạn vừa xem là câu đó, được cưỡng chế.

Dừng nói ở đó. Đừng thêm phần tóm tắt.

---

## Nếu họ hỏi

**"Có kiếm được tiền không?"**
> Đó có chủ ý không phải điều sản phẩm tuyên bố, và không có trang nào trong đó cho tôi trả lời tử tế
> câu này. Tab Outcome có return, profit factor và drawdown, và nó nằm sau một cú bấm phải chủ động
> thực hiện. Sharpe hiện đang in "not enough sessions yet" ở hai mươi mốt phiên.

**"Sao lại dùng tay cầm?"**
> Hai lý do. Nó buộc ý định phải hai tay — `clutch` và xác nhận, nên không có gì `fire` từ một cái
> giật tay. Và cái pad vốn đã kể cho ta biết người chơi đang thế nào: số vòng `clutch`, số lần
> lật `arm`, việc tăng khối lượng, vào lại nhanh cỡ nào sau một lệnh lỗ. Đó là hành vi đo được,
> không phải một bảng khảo sát tâm trạng điền sau khi xong.

**"Vậy nó phát hiện `tilt`?"**
> Nó đo hành vi và gọi tên hành vi đó — "vào lại bốn mươi giây sau một lệnh lỗ". Hai quy tắc giữ cho
> nó tử tế. `Tilt` không bao giờ là đầu vào của điểm số, vì đánh thuế buổi tối sẽ mang lại đúng cái
> trừng phạt mà cả thiết kế này tồn tại để tránh. Và `tilt` chỉ có thể làm chậm một lệnh mở. Nó không
> bao giờ được làm chậm một lệnh đóng, một lần `flatten` khẩn cấp, hay việc khóa phiên. Cái đó cũng
> là một boot-fail.

**"AI có giao dịch không?"**
> Không, và không thể bắt nó làm vậy. Nó có mười một tool chỉ đọc, và trong schema không tồn tại
> tool nào để đặt, đóng, sửa hay ghi. Mở `3c` cho họ xem.

**"Xem code được không?"**
> Chưa — đó là câu trả lời thật. Repository đã xong phần kế hoạch và chưa bắt đầu triển khai.
> Đây là các bản đặc tả được vẽ ra.

---

## Đừng nói

- Đừng gọi nó là một hệ thống giao dịch, một chiến lược, hay một `edge`.
- Đừng nói con số nào ở đây là hiệu suất thật. Đó là dữ liệu mẫu trên một tài khoản demo.
- Đừng hứa ngày. Kế hoạch là 203 giờ qua mười bốn phase và phase một chưa xong.
- Đừng mô tả `tilt` như đọc được cảm xúc. Nó đọc hành vi bấm nút.
- Đừng dùng chữ "chỉ là" cho bất kỳ cơ chế an toàn nào.

---

## Thời lượng

| Nhịp | Phút |
|---|---|
| Mở đầu | 0.5 |
| Vấn đề | 1.0 |
| Đường biên | 1.5 |
| Một buổi tối | 3.0 |
| Điểm số | 2.0 |
| Trung thực | 1.5 |
| Dùng để làm gì | 1.0 |
| Kết | 0.5 |
| **Tổng** | **11.0** |

Còn bốn phút cho câu hỏi trong một suất mười lăm phút.

Nếu chỉ có năm phút: `1i` cho bộ đếm từ chối, `1j` cho buổi tối đứng ngoài được một trăm điểm,
`2c` cho phần trung thực. Ba màn hình đó là toàn bộ luận điểm.
