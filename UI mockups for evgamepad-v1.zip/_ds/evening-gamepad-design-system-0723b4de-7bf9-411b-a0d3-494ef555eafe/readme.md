# Evening Gamepad — Design System

A design system for **Evening Forex Gold Gamepad**: a desktop Chrome web game where an 8BitDo
Ultimate 2 controller trades forex and gold on a cTrader **demo** account, wrapped in a trading
journal that grades the process rather than the money.

> The end goal is confidence and enjoyment — improving decision quality, not the money.
> Demo only. Not advice. Entertainment, not alpha.

## Sources

Everything here is derived from one repository:

- **https://github.com/laBanHSPO/evgamepad** (branch `main`) — README, the 14 phase specifications
  under `plans/260824-1506-evening-forex-gold-gamepad/`, the styled architecture document
  `docs/how-the-app-works.html`, and the concept sketch `visual01.png`.

**Important caveat about ground truth.** At the time this system was built the repository is
*planning complete, implementation not started* — there is no `apps/web` yet, no Svelte components,
no stylesheet. Two artefacts carry real visual information and both are reproduced in `assets/`:

| Artefact | What it gave us |
|---|---|
| `docs/how-the-app-works.html` | The **entire colour palette, three typefaces, radii, border weights and label treatments**, copied verbatim into `tokens/`. This is the single source of truth. |
| `visual01.png` | A hand-drawn concept of the HUD, controller map, AI desk tabs and data flow — used for layout and information hierarchy, not for pixel values. |

Everything beyond those two files (direction green/red, tilt band colours, the spacing scale, the
type scale above 28px) is **derived**, and is flagged as derived on its specimen card. When the app
ships real code, re-derive those from the implementation.

## Products

The repo describes one application with three surfaces, all desktop Chrome and dark-only:

1. **Web game HUD** (`/`) — the order path. Clutch (LT) + arm (A/B) + confirm (RT). Price tape,
   chart, position strip, adherence badge, sentinel strip, AI desk, tilt pip, confirm overlay.
   Recreated in `ui_kits/hud/`.
2. **GameOverlay** (`Menu`) — the one safe navigation surface. Opening it cancels ARM and locks new
   opens; nothing inside it can emit an order. Recreated in `ui_kits/hud/GameOverlay.jsx`.
3. **Journal cockpit and deck** (`/journal/today`, `/deck`, `/journal/history`) — prepare, review,
   and the process-first Process Score. Recreated in `ui_kits/journal/`.

---

## Content fundamentals

**Register: engineering notebook, written by the player for the player.** Declarative, exact, and
faintly dry. It states what the system does and what it refuses to do, in the same tone.

- **Person.** Mostly impersonal ("the gateway is the only component that can approve a demo order").
  Second person appears only where the player is being addressed directly and factually — the pad
  legend, a cooldown prompt. Never first-person plural marketing "we".
- **Casing.** Sentence case for all prose and headings. UPPERCASE only inside mono chips, eyebrows
  and pad glyphs: `DEMO`, `ARMED`, `SAFETY BOUNDARY`, `LT`, `RT`. Never uppercase a sentence.
- **Numbers are exact and carry their units and their sample size.** `0.42`, `+1.32R`, `19/20`,
  `n=21`, `< 16 ms`. A statistic without `n` next to it is a bug.
- **Honesty is a copy rule, not a value statement.** The system prints `grading unavailable`,
  `not enough sessions yet`, `n/a — no trades` rather than a confident placeholder. The repo's own
  latency table is literally headed "Latency budget (honest)".
- **Behaviour, never character.** Tilt copy says "re-entered 40 s after a loss", not "you are
  tilting". Failing a rule is amber information, not a red error.
- **Standing down is a win.** The stood-down counter reads upward and is coloured green; a flat
  evening in a dead tape is described as discipline.
- **No emoji.** None appear anywhere in the source and none belong here. No exclamation marks, no
  congratulation, no encouragement. The product deliberately has **no streaks, levels, badges or
  leaderboards**, so no copy may imply one.
- **Every surface carries the demo line.** `Demo only · Not advice · Process over outcome`.

Real examples, verbatim from the source:

- "Only component allowed to approve a demo order for execution."
- "Coach and transcribe; no order tools."
- "AI advises. Only the gateway approves."
- "Live endpoints and accounts fail at boot."
- "Fast demo execution in one lane; coaching, voice, and review stay safely outside it."
- "Spotware, not the VPS, is the matching engine."

Domain vocabulary to use as-is: clutch, arm, fire, flatten, stand down, tape, tilt band, adherence,
selectivity, opportunity quality (OQ), playbook, grade, R, process score, off-path, hot path.

---

## Visual foundations

**Colour.** One dark ground and one accent. `--paper` `#0b1017` behind everything, `--paper-2`
`#141b24` for cards, `--ink` `#e6edf3` for text, `--muted` and `--soft` for the two demotions below
it. Exactly two brand hues: **amber `#f4b860` means enforcement** — the one component allowed to
approve an order — and **blue `#60a5fa` means the live order path** (and links). Green and red exist
only for market direction and signed R. There is no third accent, no gradient, and no tint of the
background beyond stepped `rgba(230,237,243,…)` alphas. Never introduce a purple, a teal, or a
gradient; the palette is closed.

**Type.** Three families, each with one job. *Instrument Serif* for editorial voice — the takeaway
line, a section title, a pull quote; italic is its emphatic form. *Geist* for every sentence the UI
speaks. *Geist Mono* for every number, every chip, every uppercase label, and every protocol string,
always with tabular figures. The tell of this system is the mono eyebrow: 10px, uppercase, tracked
`0.18em` for sections and `0.14em` for panel labels.

**Backgrounds.** Flat. No imagery, no texture, no pattern, no gradient anywhere in the source. Zones
are drawn as a `rgba(230,237,243,0.02)` fill inside a hairline border with a small label chip
notched into the top edge. The only pictures in the product are the player's own attached chart
screenshots.

**Layout.** A 1280px canvas with a 960px minimum — this is a desktop-only, focused-tab product with
no responsive story and no mobile breakpoints. Content sits on a strict 4px grid. The HUD is three
columns (instrument · chart · desk); the session bar is a fixed 44px top rail present on every
surface. Whitespace is generous by dashboard standards: this is deliberately "not a DOM-dense
Bloomberg clone".

**Cards.** 8px radius, 1px hairline border at 14% ink, flat fill, **no shadow**. Chips and buttons
are 4px radius. That is the whole vocabulary — two radii, three border weights (`0.8px` hairline,
`1px` standard, `1.2px` enforcement).

**Border style carries meaning.** Solid amber at 1.2px = can approve or block an order. Dashed at
`4 4` = can *never* place an order (the AI desk, voice workers, the journal). This is copied
directly from the architecture diagram's legend and it must not be used decoratively.

**Shadows and glow.** No drop shadows exist in this system. Two glows do, and both mean *live right
now*: `--glow-armed` (amber ring plus 24px bloom, on the ARM confirm overlay) and `--glow-live`
(blue). Depth otherwise comes from alpha fills and hairlines only.

**Transparency and blur.** Only the GameOverlay blurs, at `blur(6px)` over an 86% paper scrim —
because the game keeps running underneath and the player must see that it did. Panels are never
frosted.

**Motion.** Instrumentation, not decoration. 80ms linear for value ticks and meter fills; 120ms for
hover and tab changes; 180ms for panel state; 220ms for the overlay. Standard easing is
`cubic-bezier(0.2,0,0,1)`. **Nothing bounces, nothing springs, nothing pulses for attention.** The
single long duration in the system is 750ms — the hot-tilt confirm hold — and it is slow on purpose.

**Hover and press.** Hover lightens the surface by one alpha step (`0.05` → `0.08`) and lifts text
from `--muted` to `--ink`; it never changes hue and never scales. Press nudges 1px down. Focus is a
1px accent ring. Disabled is 45% opacity with the border retained — unavailable controls stay
visible rather than disappearing, which is why the `Memo` desk tab ships disabled and labelled.

**Imagery.** There is none, by design. Where a photograph would go, the product shows the tape.

---

## Iconography

**The product's icon system is the controller.** Instructions name physical 8BitDo buttons rather
than drawing symbols: `LT` hold, `A` arm buy, `RT` confirm, `Y` flatten. `PadGlyph` renders these —
face buttons as coloured circles on the Xbox convention (A green, B red, X blue, Y amber), triggers,
bumpers and system buttons as outlined 4px-radius rects with mono labels. Use it anywhere the player
needs to know what to press.

Beyond that, the source repo contains **no icon set, no icon font and no SVG sprite**. The
architecture diagram draws only rectangles, lines and arrow markers. Accordingly this system uses
almost no icons:

- **Status is a 5–7px filled circle**, coloured by state (`--long` ok, `--accent` warn, `--short`
  alert, `--soft` idle). This is the only "icon" on the HUD besides pad glyphs.
- **Direction and flow use hairlines with arrow markers**, solid for the hot path, dashed `4 4` for
  events and off-path work.
- **No emoji, ever.** No unicode symbol characters as icons either — write the word.

If a future screen genuinely needs a glyph set (an export icon, a chevron), link **Lucide** from CDN
at 1.5px stroke, which matches the diagram's line weight, and note it as a substitution — the brand
does not own an icon set yet.

**No logo exists.** The repository contains no wordmark, lockup or brand mark. Nothing here invents
one: where a mark would go, render the product name in Instrument Serif. Ask the maintainer for a
logo before shipping anything that needs one.

---

## Index

| Path | What it is |
|---|---|
| `styles.css` | The one file consumers link. `@import` list only. |
| `tokens/` | `fonts.css` `colors.css` `typography.css` `spacing.css` `surfaces.css` `motion.css` `base.css` |
| `guidelines/` | Foundation specimen cards — Colors, Type, Spacing, Brand. |
| `assets/` | `visual01-concept.png` (concept sketch), `how-the-app-works.svg` (architecture diagram). No logo. |
| `components/` | Reusable primitives, below. |
| `ui_kits/hud/` | Web game HUD recreation, interactive. |
| `ui_kits/journal/` | Journal cockpit and process deck recreation, interactive. |
| `SKILL.md` | Agent-skill entry point. |
| `github.md` | Source repository association and sync record. |

### Components

Grouped by concern. Each directory holds `<Name>.jsx`, `<Name>.d.ts`, `<Name>.prompt.md` and one
`@dsCard` HTML.

- **`components/core/`** — `Panel`, `Badge`, `Button`, `Eyebrow`, `StatTile`, `Tabs`
- **`components/pad/`** — `PadGlyph`, `ClutchMeter`, `TiltPip`
- **`components/hud/`** — `SessionBar`, `PriceTape`, `PositionStrip`, `AdherenceBadge`,
  `SentinelBar`, `ConfirmOverlay`
- **`components/deck/`** — `ScoreRadar`, `AxisBar`, `MetricTile`
- **`components/journal/`** — `WorldClocks`, `ReadinessChecklist`, `ProcessHeatmap`, `MistakeTag`

The inventory follows the Svelte component list the phase files declare (`PriceTape.svelte`,
`ConfirmOverlay.svelte`, `AdherenceBadge.svelte`, `ScoreRadar.svelte`, `Heatmap.svelte`, …), one
primitive per declared surface element.

**Intentional additions.** Four primitives have no single named counterpart in the plans and were
added because every screen needs them: `Panel` (the bordered zone the diagram draws everywhere),
`Badge`, `Button` and `Eyebrow` (the mono label treatment used on every artefact). `StatTile`,
`AxisBar`, `MetricTile` and `MistakeTag` factor out repeated structures the phase files describe in
prose rather than naming as components.

**Not built.** The plans also name `Chart` (Lightweight Charts, a third-party library),
`CheckIn`, `PlaybookStats`, `TiltRetro`, `TradeDetail`, `TradeQuality`, `MistakeTrends`,
`SystemPrinciples`, `History`, `Today` and `WorldSessions` — these are *screens or compositions*,
not primitives, and appear inside the UI kits rather than as standalone components.

---

Demo only · Not advice · Process over outcome
