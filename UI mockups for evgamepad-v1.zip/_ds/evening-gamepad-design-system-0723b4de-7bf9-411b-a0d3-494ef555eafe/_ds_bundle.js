/* @ds-bundle: {"format":4,"namespace":"EveningGamepadDesignSystem_0723b4","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Panel","sourcePath":"components/core/Panel.jsx"},{"name":"StatTile","sourcePath":"components/core/StatTile.jsx"},{"name":"Tabs","sourcePath":"components/core/Tabs.jsx"},{"name":"AxisBar","sourcePath":"components/deck/AxisBar.jsx"},{"name":"MetricTile","sourcePath":"components/deck/MetricTile.jsx"},{"name":"ScoreRadar","sourcePath":"components/deck/ScoreRadar.jsx"},{"name":"AdherenceBadge","sourcePath":"components/hud/AdherenceBadge.jsx"},{"name":"ConfirmOverlay","sourcePath":"components/hud/ConfirmOverlay.jsx"},{"name":"PositionStrip","sourcePath":"components/hud/PositionStrip.jsx"},{"name":"PriceTape","sourcePath":"components/hud/PriceTape.jsx"},{"name":"SentinelBar","sourcePath":"components/hud/SentinelBar.jsx"},{"name":"SessionBar","sourcePath":"components/hud/SessionBar.jsx"},{"name":"MistakeTag","sourcePath":"components/journal/MistakeTag.jsx"},{"name":"ProcessHeatmap","sourcePath":"components/journal/ProcessHeatmap.jsx"},{"name":"ReadinessChecklist","sourcePath":"components/journal/ReadinessChecklist.jsx"},{"name":"WorldClocks","sourcePath":"components/journal/WorldClocks.jsx"},{"name":"ClutchMeter","sourcePath":"components/pad/ClutchMeter.jsx"},{"name":"PadGlyph","sourcePath":"components/pad/PadGlyph.jsx"},{"name":"TiltPip","sourcePath":"components/pad/TiltPip.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"057297e28ee6","components/core/Button.jsx":"698613fdcd68","components/core/Eyebrow.jsx":"2ca2f49b0e05","components/core/Panel.jsx":"5735096544e0","components/core/StatTile.jsx":"ab34f645774a","components/core/Tabs.jsx":"d225f0ca3039","components/deck/AxisBar.jsx":"61faa1553212","components/deck/MetricTile.jsx":"8323d92d0a3c","components/deck/ScoreRadar.jsx":"313f2128a1b8","components/hud/AdherenceBadge.jsx":"75ca50fb2008","components/hud/ConfirmOverlay.jsx":"03f95032732e","components/hud/PositionStrip.jsx":"ad4dff31869d","components/hud/PriceTape.jsx":"a9427ea452ef","components/hud/SentinelBar.jsx":"7de4092d8853","components/hud/SessionBar.jsx":"8e1943cc817f","components/journal/MistakeTag.jsx":"ee049317c05a","components/journal/ProcessHeatmap.jsx":"02b750a21e08","components/journal/ReadinessChecklist.jsx":"af7f7de6fed0","components/journal/WorldClocks.jsx":"00ae32af2041","components/pad/ClutchMeter.jsx":"54ccfc787b2a","components/pad/PadGlyph.jsx":"543ece0745fe","components/pad/TiltPip.jsx":"ecf0b8b310fd","ui_kits/hud/CandleChart.jsx":"1d8b50258171","ui_kits/hud/CopilotDesk.jsx":"13c102e19901","ui_kits/hud/GameOverlay.jsx":"0f64f9ee6d72","ui_kits/hud/HudScreen.jsx":"cfb61fd1c5af","ui_kits/journal/DeckScreen.jsx":"5bbbd8ab406c","ui_kits/journal/HistoryScreen.jsx":"985f246e5669","ui_kits/journal/TodayScreen.jsx":"8a8887e34cd6","ui_kits/journal/data.js":"5ebc94f9d3a1"},"inlinedExternals":[],"unexposedExports":[{"name":"band","sourcePath":"components/pad/TiltPip.jsx"}]} */

(() => {

const __ds_ns = (window.EveningGamepadDesignSystem_0723b4 = window.EveningGamepadDesignSystem_0723b4 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: {
    fg: 'var(--muted)',
    line: 'rgba(154,167,181,0.45)',
    fill: 'rgba(154,167,181,0.10)'
  },
  ink: {
    fg: 'var(--ink)',
    line: 'rgba(230,237,243,0.40)',
    fill: 'var(--ink-05)'
  },
  accent: {
    fg: 'var(--accent)',
    line: 'rgba(244,184,96,0.55)',
    fill: 'var(--accent-tint)'
  },
  link: {
    fg: 'var(--link)',
    line: 'rgba(96,165,250,0.55)',
    fill: 'var(--link-tint)'
  },
  long: {
    fg: 'var(--long)',
    line: 'rgba(74,222,128,0.55)',
    fill: 'var(--long-tint)'
  },
  short: {
    fg: 'var(--short)',
    line: 'rgba(248,113,113,0.55)',
    fill: 'var(--short-tint)'
  },
  soft: {
    fg: 'var(--soft)',
    line: 'var(--rule)',
    fill: 'transparent'
  }
};
function Badge({
  children,
  tone = 'neutral',
  variant = 'outline',
  dot = false,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: '18px',
      padding: '0 var(--space-2)',
      borderRadius: 'var(--radius-chip)',
      border: '0.8px solid ' + (variant === 'plain' ? 'transparent' : t.line),
      background: variant === 'solid' ? t.fill : 'transparent',
      color: t.fg,
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      letterSpacing: 'var(--tracking-chip)',
      textTransform: 'uppercase',
      whiteSpace: 'nowrap',
      ...style
    }
  }), dot && /*#__PURE__*/React.createElement("i", {
    style: {
      width: 5,
      height: 5,
      borderRadius: '50%',
      background: t.fg,
      display: 'block'
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VARIANTS = {
  primary: {
    bg: 'var(--accent-tint)',
    fg: 'var(--accent)',
    bd: 'var(--accent)',
    hover: 'rgba(244,184,96,0.20)'
  },
  secondary: {
    bg: 'var(--ink-05)',
    fg: 'var(--ink)',
    bd: 'var(--rule-strong)',
    hover: 'var(--ink-08)'
  },
  ghost: {
    bg: 'transparent',
    fg: 'var(--muted)',
    bd: 'var(--rule)',
    hover: 'var(--ink-03)'
  },
  danger: {
    bg: 'var(--short-tint)',
    fg: 'var(--short)',
    bd: 'var(--short)',
    hover: 'rgba(248,113,113,0.20)'
  }
};
const SIZES = {
  sm: {
    height: 24,
    font: 'var(--text-micro)',
    pad: '0 var(--space-2)'
  },
  md: {
    height: 32,
    font: 'var(--text-label)',
    pad: '0 var(--space-4)'
  }
};
function Button({
  children,
  variant = 'secondary',
  size = 'md',
  disabled = false,
  glyph,
  style,
  ...rest
}) {
  const v = VARIANTS[variant] || VARIANTS.secondary;
  const s = SIZES[size] || SIZES.md;
  const [hover, setHover] = React.useState(false);
  const [down, setDown] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({}, rest, {
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setDown(false);
    },
    onMouseDown: () => setDown(true),
    onMouseUp: () => setDown(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 'var(--space-2)',
      height: s.height,
      padding: s.pad,
      borderRadius: 'var(--radius-chip)',
      border: '1px solid ' + v.bd,
      background: disabled ? 'transparent' : hover && !down ? v.hover : v.bg,
      color: disabled ? 'var(--soft)' : v.fg,
      opacity: disabled ? 0.45 : 1,
      fontFamily: 'var(--font-mono)',
      fontSize: s.font,
      letterSpacing: 'var(--tracking-chip)',
      textTransform: 'uppercase',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transform: down ? 'translateY(1px)' : 'none',
      transition: 'background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard)',
      ...style
    }
  }), glyph, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  tertiary: 'var(--text-tertiary)',
  secondary: 'var(--text-secondary)',
  accent: 'var(--text-accent)',
  link: 'var(--text-link)',
  ink: 'var(--text-body)'
};
function Eyebrow({
  children,
  tone = 'tertiary',
  tracking = 'eyebrow',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      letterSpacing: tracking === 'label' ? 'var(--tracking-label)' : 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: TONES[tone] || TONES.tertiary,
      lineHeight: 1,
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Panel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VARIANTS = {
  default: {
    background: 'var(--surface-card)',
    border: '1px solid var(--rule)'
  },
  sunken: {
    background: 'var(--surface-sunken)',
    border: '1px solid var(--rule)'
  },
  raised: {
    background: 'var(--surface-raised)',
    border: '1px solid var(--muted)'
  },
  enforce: {
    background: 'var(--accent-tint)',
    border: '1.2px solid var(--accent)'
  },
  offpath: {
    background: 'var(--ink-02)',
    border: '1px dashed var(--rule-soft)'
  }
};
function Panel({
  label,
  tag,
  variant = 'default',
  padding = 'var(--space-4)',
  children,
  style,
  ...rest
}) {
  const v = VARIANTS[variant] || VARIANTS.default;
  return /*#__PURE__*/React.createElement("section", _extends({}, rest, {
    style: {
      borderRadius: 'var(--radius-card)',
      padding,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      ...v,
      ...style
    }
  }), (label || tag) && /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-3)'
    }
  }, label && /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tone: variant === 'enforce' ? 'accent' : 'tertiary',
    tracking: "label"
  }, label), tag), children);
}
Object.assign(__ds_scope, { Panel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Panel.jsx", error: String((e && e.message) || e) }); }

// components/core/StatTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  ink: 'var(--ink)',
  long: 'var(--long)',
  short: 'var(--short)',
  accent: 'var(--accent)',
  link: 'var(--link)',
  muted: 'var(--muted)'
};
function StatTile({
  label,
  value,
  unit,
  sub,
  tone = 'ink',
  size = 'md',
  align = 'left',
  style,
  ...rest
}) {
  const fs = size === 'lg' ? 'var(--text-2xl)' : size === 'sm' ? 'var(--text-md)' : 'var(--text-lg)';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tracking: "label"
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--space-1)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontVariantNumeric: 'tabular-nums',
      fontSize: fs,
      lineHeight: 1,
      letterSpacing: 'var(--tracking-tape)',
      color: TONES[tone] || TONES.ink
    }
  }, value), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--muted)'
    }
  }, unit)), sub && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)'
    }
  }, sub));
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/core/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  items = [],
  value,
  onChange,
  hint,
  size = 'md',
  style,
  ...rest
}) {
  const h = size === 'sm' ? 22 : 28;
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      borderBottom: '1px solid var(--rule)',
      minWidth: 0,
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'var(--space-1)',
      minWidth: 0
    }
  }, items.map(it => {
    const active = it.id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      disabled: it.disabled,
      onClick: () => !it.disabled && onChange && onChange(it.id),
      style: {
        height: h,
        padding: '0 var(--space-3)',
        background: active ? 'var(--ink-05)' : 'transparent',
        border: 'none',
        borderBottom: '2px solid ' + (active ? 'var(--accent)' : 'transparent'),
        color: it.disabled ? 'var(--soft)' : active ? 'var(--ink)' : 'var(--muted)',
        opacity: it.disabled ? 0.5 : 1,
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-label)',
        letterSpacing: 'var(--tracking-chip)',
        cursor: it.disabled ? 'not-allowed' : 'pointer',
        transition: 'color var(--dur-fast) var(--ease-standard)'
      }
    }, it.label);
  })), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      whiteSpace: 'nowrap',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: 'var(--soft)',
      letterSpacing: 'var(--tracking-chip)'
    }
  }, hint));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/deck/AxisBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function AxisBar({
  label,
  value,
  weight,
  note,
  style,
  ...rest
}) {
  const na = value == null;
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tracking: "label"
  }, label), weight != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: 'var(--soft)'
    }
  }, "w ", weight.toFixed(2)), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      marginLeft: 'auto',
      fontSize: 'var(--text-sm)',
      color: na ? 'var(--soft)' : 'var(--ink)'
    }
  }, na ? 'n/a' : value)), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      borderRadius: 'var(--radius-chip)',
      background: 'var(--ink-05)',
      border: na ? '1px dashed var(--rule-soft)' : '0.8px solid var(--rule)',
      overflow: 'hidden'
    }
  }, !na && /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: value + '%',
      background: 'var(--accent)',
      opacity: 0.9
    }
  })), note && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)'
    }
  }, note));
}
Object.assign(__ds_scope, { AxisBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/deck/AxisBar.jsx", error: String((e && e.message) || e) }); }

// components/deck/MetricTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function MetricTile({
  label,
  value,
  unit,
  delta,
  sample,
  lowN,
  note,
  tone = 'ink',
  style,
  ...rest
}) {
  const dTone = delta == null ? null : delta >= 0 ? 'var(--long)' : 'var(--short)';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      padding: 'var(--space-3)',
      border: '1px solid var(--rule)',
      borderRadius: 'var(--radius-card)',
      background: 'var(--surface-sunken)',
      minWidth: 140,
      ...style
    }
  }), lowN ? /*#__PURE__*/React.createElement(__ds_scope.StatTile, {
    label: label,
    value: "\u2014",
    size: "sm",
    tone: "muted",
    sub: "not enough sessions yet"
  }) : /*#__PURE__*/React.createElement(__ds_scope.StatTile, {
    label: label,
    value: value,
    unit: unit,
    tone: tone,
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)'
    }
  }, delta != null && !lowN && /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-xs)',
      color: dTone
    }
  }, delta >= 0 ? '+' : '', delta, " vs last month"), sample != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: 'var(--soft)',
      marginLeft: 'auto'
    }
  }, "n=", sample)), note && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)'
    }
  }, note));
}
Object.assign(__ds_scope, { MetricTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/deck/MetricTile.jsx", error: String((e && e.message) || e) }); }

// components/deck/ScoreRadar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ScoreRadar({
  axes = [],
  total,
  size = 240,
  style,
  ...rest
}) {
  const n = axes.length || 5;
  const cx = size / 2,
    cy = size / 2,
    R = size / 2 - 34;
  const pt = (i, f) => {
    const a = -Math.PI / 2 + i * 2 * Math.PI / n;
    return [cx + Math.cos(a) * R * f, cy + Math.sin(a) * R * f];
  };
  const rings = [0.25, 0.5, 0.75, 1].map(f => axes.map((_, i) => pt(i, f).join(',')).join(' '));
  const present = axes.map((a, i) => a.value == null ? null : pt(i, a.value / 100));
  const poly = present.filter(Boolean).map(p => p.join(',')).join(' ');
  const naIdx = axes.map((a, i) => a.value == null ? i : -1).filter(i => i >= 0);
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-6)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: '0 0 ' + size + ' ' + size,
    style: {
      display: 'block',
      overflow: 'visible'
    }
  }, rings.map((r, i) => /*#__PURE__*/React.createElement("polygon", {
    key: i,
    points: r,
    fill: "none",
    stroke: "var(--rule)",
    strokeWidth: "0.8"
  })), axes.map((a, i) => {
    const [x, y] = pt(i, 1);
    const na = a.value == null;
    return /*#__PURE__*/React.createElement("line", {
      key: a.key || i,
      x1: cx,
      y1: cy,
      x2: x,
      y2: y,
      stroke: na ? 'var(--soft)' : 'var(--rule)',
      strokeWidth: na ? 1 : 0.8,
      strokeDasharray: na ? '4 4' : undefined
    });
  }), poly && /*#__PURE__*/React.createElement("polygon", {
    points: poly,
    fill: "var(--accent-tint)",
    stroke: "var(--accent)",
    strokeWidth: "1.2",
    strokeLinejoin: "round"
  }), present.map((p, i) => p && /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: p[0],
    cy: p[1],
    r: "2.5",
    fill: "var(--accent)"
  })), naIdx.map(i => {
    const [x, y] = pt(i, 1);
    return /*#__PURE__*/React.createElement("circle", {
      key: 'na' + i,
      cx: x,
      cy: y,
      r: "4",
      fill: "none",
      stroke: "var(--soft)",
      strokeWidth: "1",
      strokeDasharray: "3 3"
    });
  }), axes.map((a, i) => {
    const [x, y] = pt(i, 1.24);
    return /*#__PURE__*/React.createElement("text", {
      key: 'l' + i,
      x: x,
      y: y,
      fill: a.value == null ? 'var(--soft)' : 'var(--muted)',
      fontFamily: "var(--font-mono)",
      fontSize: "9",
      letterSpacing: "0.1em",
      textAnchor: "middle",
      dominantBaseline: "middle"
    }, (a.label || '').toUpperCase());
  })), total != null && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "ev-eyebrow"
  }, "Process score"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-2xl)',
      lineHeight: 1,
      color: 'var(--ink)'
    }
  }, total), naIdx.length > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: 'var(--soft)'
    }
  }, naIdx.length, " axis n/a \u2014 renormalised")));
}
Object.assign(__ds_scope, { ScoreRadar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/deck/ScoreRadar.jsx", error: String((e && e.message) || e) }); }

// components/hud/AdherenceBadge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function AdherenceBadge({
  rules = [],
  stoodDown = 0,
  style,
  ...rest
}) {
  const passed = rules.filter(r => r.ok).length;
  const all = passed === rules.length && rules.length > 0;
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      padding: 'var(--space-3)',
      border: '1px solid ' + (all ? 'rgba(74,222,128,0.35)' : 'var(--rule)'),
      borderRadius: 'var(--radius-card)',
      background: all ? 'var(--long-tint)' : 'var(--surface-sunken)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tracking: "label"
  }, "Adherence"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-label)',
      color: all ? 'var(--long)' : 'var(--accent)'
    }
  }, passed, "/", rules.length)), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, rules.map(r => /*#__PURE__*/React.createElement("li", {
    key: r.label,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      fontSize: 'var(--text-xs)',
      color: r.ok ? 'var(--muted)' : 'var(--ink)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: r.ok ? 'var(--long)' : 'var(--accent)',
      display: 'block',
      flex: '0 0 auto'
    }
  }), r.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingTop: 'var(--space-2)',
      borderTop: '1px solid var(--rule)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tracking: "label"
  }, "Stood down"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-md)',
      color: 'var(--long)'
    }
  }, stoodDown)));
}
Object.assign(__ds_scope, { AdherenceBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/AdherenceBadge.jsx", error: String((e && e.message) || e) }); }

// components/hud/PositionStrip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function PositionStrip({
  position,
  showDollars = false,
  empty = 'Flat — no open position',
  style,
  ...rest
}) {
  if (!position) {
    return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)',
        height: 64,
        padding: '0 var(--space-4)',
        border: '1px solid var(--rule)',
        borderRadius: 'var(--radius-card)',
        background: 'var(--surface-sunken)',
        ...style
      }
    }), /*#__PURE__*/React.createElement(__ds_scope.Badge, {
      tone: "soft",
      dot: true
    }, "Flat"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-xs)',
        color: 'var(--soft)'
      }
    }, empty));
  }
  const long = position.side === 'BUY';
  const tone = position.r >= 0 ? 'long' : 'short';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-6)',
      minHeight: 64,
      padding: 'var(--space-3) var(--space-4)',
      border: '1px solid var(--rule)',
      borderLeft: '2px solid ' + (long ? 'var(--long)' : 'var(--short)'),
      borderRadius: 'var(--radius-card)',
      background: 'var(--surface-card)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: long ? 'long' : 'short',
    variant: "solid"
  }, position.side, " ", position.lots), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--muted)'
    }
  }, position.symbol, " @ ", position.entry)), /*#__PURE__*/React.createElement(__ds_scope.StatTile, {
    label: "P/L",
    value: (position.r >= 0 ? '+' : '') + position.r.toFixed(2),
    unit: "R",
    tone: tone,
    size: "sm"
  }), showDollars && /*#__PURE__*/React.createElement(__ds_scope.StatTile, {
    label: "P/L ($)",
    value: (position.pnlUsd >= 0 ? '+' : '') + position.pnlUsd.toFixed(2),
    tone: tone,
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "SL"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--short)'
    }
  }, position.sl)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "TP"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--long)'
    }
  }, position.tp)), position.playbook && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "Playbook"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--ink)'
    }
  }, position.playbook)));
}
Object.assign(__ds_scope, { PositionStrip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/PositionStrip.jsx", error: String((e && e.message) || e) }); }

// components/hud/PriceTape.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function PriceTape({
  symbol = 'XAUUSD',
  timeframe = 'M5',
  last,
  direction = 'flat',
  bid,
  ask,
  spread,
  style,
  ...rest
}) {
  const color = direction === 'up' ? 'var(--long)' : direction === 'down' ? 'var(--short)' : 'var(--ink)';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--text-md)',
      fontWeight: 600,
      color: 'var(--ink)',
      letterSpacing: '0.01em'
    }
  }, symbol), /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "soft"
  }, timeframe)), /*#__PURE__*/React.createElement("div", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-2xl)',
      lineHeight: 1,
      letterSpacing: 'var(--tracking-tape)',
      color
    }
  }, last), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "Bid"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--short)'
    }
  }, bid)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "Ask"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--long)'
    }
  }, ask)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "Spread"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--muted)'
    }
  }, spread))));
}
Object.assign(__ds_scope, { PriceTape });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/PriceTape.jsx", error: String((e && e.message) || e) }); }

// components/hud/SentinelBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STATES = {
  ok: 'var(--long)',
  warn: 'var(--accent)',
  alert: 'var(--short)',
  idle: 'var(--soft)'
};
function SentinelBar({
  items = [],
  quality,
  layout = 'stack',
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tracking: "label"
  }, "Sentinel"), quality && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: 'var(--muted)',
      letterSpacing: 'var(--tracking-chip)'
    }
  }, "OQ ", quality)), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      display: 'flex',
      flexDirection: layout === 'row' ? 'row' : 'column',
      gap: layout === 'row' ? 'var(--space-5)' : 'var(--space-2)',
      flexWrap: 'wrap'
    }
  }, items.map(it => /*#__PURE__*/React.createElement("li", {
    key: it.label,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      fontSize: 'var(--text-xs)',
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: STATES[it.state] || STATES.idle,
      display: 'block',
      flex: '0 0 auto'
    }
  }), it.label))));
}
Object.assign(__ds_scope, { SentinelBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/SentinelBar.jsx", error: String((e && e.message) || e) }); }

// components/hud/SessionBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SessionBar({
  title = 'Web game HUD',
  window: win = '18:00 – 23:30',
  clock,
  remaining,
  locked = false,
  connected = true,
  right,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      height: 44,
      padding: '0 var(--space-4)',
      borderBottom: '1px solid var(--rule)',
      background: 'var(--surface-card)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: connected ? 'var(--long)' : 'var(--short)',
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tone: "ink",
    tracking: "label"
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 'var(--space-3)',
      marginLeft: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "Session"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--ink)'
    }
  }, clock), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--soft)'
    }
  }, "/ ", win), remaining && /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--muted)'
    }
  }, remaining, " left")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)'
    }
  }, right, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: locked ? 'soft' : 'long',
    dot: true
  }, locked ? 'Locked' : 'Unlocked'), /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "link",
    variant: "solid"
  }, "Demo")));
}
Object.assign(__ds_scope, { SessionBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/SessionBar.jsx", error: String((e && e.message) || e) }); }

// components/journal/MistakeTag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function MistakeTag({
  label,
  count,
  trend,
  custom = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      height: 22,
      padding: '0 var(--space-2)',
      borderRadius: 'var(--radius-chip)',
      border: '0.8px ' + (custom ? 'dashed' : 'solid') + ' var(--rule-soft)',
      background: 'var(--ink-03)',
      color: 'var(--muted)',
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--text-xs)',
      ...style
    }
  }), label, count != null && /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      color: 'var(--ink)'
    }
  }, count), trend != null && /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-micro)',
      color: trend > 0 ? 'var(--short)' : 'var(--long)'
    }
  }, trend > 0 ? '+' : '', trend));
}
Object.assign(__ds_scope, { MistakeTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/journal/MistakeTag.jsx", error: String((e && e.message) || e) }); }

// components/journal/ProcessHeatmap.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function cell(score, trades) {
  if (score == null) return {
    bg: 'var(--ink-03)',
    bd: 'var(--rule)',
    fg: 'var(--soft)'
  };
  const a = 0.10 + score / 100 * 0.55;
  return {
    bg: 'rgba(74,222,128,' + a.toFixed(2) + ')',
    bd: trades === 0 ? 'var(--rule-soft)' : 'rgba(74,222,128,0.45)',
    fg: score >= 60 ? 'var(--ink)' : 'var(--muted)'
  };
}
function ProcessHeatmap({
  days = [],
  columns = 7,
  selected,
  onSelect,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(' + columns + ', 1fr)',
      gap: 'var(--space-1)',
      ...style
    }
  }), days.map(d => {
    const c = cell(d.score, d.trades);
    const on = selected === d.date;
    return /*#__PURE__*/React.createElement("button", {
      key: d.date,
      onClick: () => onSelect && onSelect(d.date),
      title: d.date + (d.score == null ? ' · no session' : ' · score ' + d.score + ' · ' + d.trades + ' trades'),
      style: {
        aspectRatio: '1',
        borderRadius: 'var(--radius-chip)',
        background: c.bg,
        border: on ? '1.2px solid var(--accent)' : '0.8px solid ' + c.bd,
        color: c.fg,
        fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-micro)',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'border-color var(--dur-fast) var(--ease-standard)'
      }
    }, d.score == null ? '' : d.score);
  }));
}
Object.assign(__ds_scope, { ProcessHeatmap });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/journal/ProcessHeatmap.jsx", error: String((e && e.message) || e) }); }

// components/journal/ReadinessChecklist.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ReadinessChecklist({
  items = [],
  onToggle,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("ul", _extends({}, rest, {
    style: {
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }), items.map(it => {
    const yes = it.value === true,
      no = it.value === false;
    return /*#__PURE__*/React.createElement("li", {
      key: it.id,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)',
        padding: 'var(--space-2) var(--space-3)',
        borderRadius: 'var(--radius-chip)',
        background: 'var(--ink-02)',
        border: '1px solid var(--rule)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-sm)',
        color: yes ? 'var(--ink)' : 'var(--muted)',
        flex: 1
      }
    }, it.label), it.note && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-xs)',
        color: 'var(--soft)'
      }
    }, it.note), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        gap: 4
      }
    }, ['yes', 'no'].map(k => {
      const on = k === 'yes' && yes || k === 'no' && no;
      const c = k === 'yes' ? 'var(--long)' : 'var(--muted)';
      return /*#__PURE__*/React.createElement("button", {
        key: k,
        onClick: () => onToggle && onToggle(it.id, k === 'yes'),
        style: {
          height: 20,
          padding: '0 8px',
          borderRadius: 'var(--radius-chip)',
          border: '0.8px solid ' + (on ? c : 'var(--rule)'),
          background: on ? k === 'yes' ? 'var(--long-tint)' : 'var(--ink-05)' : 'transparent',
          color: on ? c : 'var(--soft)',
          fontFamily: 'var(--font-mono)',
          fontSize: 'var(--text-micro)',
          textTransform: 'uppercase',
          letterSpacing: 'var(--tracking-chip)',
          cursor: 'pointer'
        }
      }, k);
    })));
  }), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "Advisory \u2014 never blocks unlock or trading")));
}
Object.assign(__ds_scope, { ReadinessChecklist });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/journal/ReadinessChecklist.jsx", error: String((e && e.message) || e) }); }

// components/journal/WorldClocks.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function WorldClocks({
  zones = [],
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      ...style
    }
  }), zones.map(z => /*#__PURE__*/React.createElement("div", {
    key: z.city,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: 5,
      height: 5,
      borderRadius: '50%',
      background: z.open ? 'var(--long)' : 'var(--soft)',
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tracking: "label"
  }, z.city)), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-md)',
      color: z.open ? 'var(--ink)' : 'var(--muted)'
    }
  }, z.time), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: 'var(--soft)'
    }
  }, z.zone))));
}
Object.assign(__ds_scope, { WorldClocks });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/journal/WorldClocks.jsx", error: String((e && e.message) || e) }); }

// components/pad/ClutchMeter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ClutchMeter({
  value = 0,
  armed = false,
  on = 0.8,
  off = 0.5,
  showLabel = true,
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(1, value)) * 100;
  const engaged = value >= on;
  const fill = armed ? 'var(--accent)' : engaged ? 'var(--long)' : 'var(--muted)';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }), showLabel && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tracking: "label"
  }, "Clutch"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-micro)',
      color: armed ? 'var(--accent)' : engaged ? 'var(--long)' : 'var(--soft)',
      letterSpacing: 'var(--tracking-chip)'
    }
  }, armed ? 'ARMED' : engaged ? 'ENGAGED' : 'OPEN')), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      height: 10,
      borderRadius: 'var(--radius-chip)',
      background: 'var(--ink-05)',
      border: '0.8px solid var(--rule)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      width: pct + '%',
      background: fill,
      opacity: 0.85,
      transition: 'width var(--dur-instant) var(--ease-linear)'
    }
  }), /*#__PURE__*/React.createElement("i", {
    style: {
      position: 'absolute',
      top: 0,
      bottom: 0,
      left: off * 100 + '%',
      width: 1,
      background: 'var(--rule-strong)'
    }
  }), /*#__PURE__*/React.createElement("i", {
    style: {
      position: 'absolute',
      top: 0,
      bottom: 0,
      left: on * 100 + '%',
      width: 1,
      background: 'var(--ink)'
    }
  })));
}
Object.assign(__ds_scope, { ClutchMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/pad/ClutchMeter.jsx", error: String((e && e.message) || e) }); }

// components/pad/PadGlyph.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const FACE = {
  A: 'var(--long)',
  B: 'var(--short)',
  X: 'var(--link)',
  Y: 'var(--accent)'
};
function PadGlyph({
  button,
  active = false,
  size = 'md',
  style,
  ...rest
}) {
  const face = FACE[button];
  const s = size === 'sm' ? {
    h: 16,
    f: 'var(--text-micro)',
    p: '0 5px'
  } : {
    h: 20,
    f: 'var(--text-label)',
    p: '0 var(--space-2)'
  };
  const color = face || (active ? 'var(--ink)' : 'var(--muted)');
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: face ? s.h : undefined,
      height: s.h,
      padding: face ? 0 : s.p,
      borderRadius: face ? '50%' : 'var(--radius-chip)',
      border: '0.8px solid ' + color,
      background: active ? 'var(--ink-08)' : 'transparent',
      color,
      fontFamily: 'var(--font-mono)',
      fontSize: s.f,
      lineHeight: 1,
      letterSpacing: face ? 0 : 'var(--tracking-chip)',
      whiteSpace: 'nowrap',
      ...style
    }
  }), button);
}
Object.assign(__ds_scope, { PadGlyph });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/pad/PadGlyph.jsx", error: String((e && e.message) || e) }); }

// components/hud/ConfirmOverlay.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ConfirmOverlay({
  side = 'BUY',
  lots = '0.10',
  symbol = 'XAUUSD',
  price,
  sl,
  tp,
  r,
  grade,
  driver,
  holdMs = 0,
  style,
  ...rest
}) {
  const long = side === 'BUY';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      position: 'relative',
      maxWidth: 520,
      padding: 'var(--space-6)',
      borderRadius: 'var(--radius-card)',
      border: '1.2px solid var(--accent)',
      background: 'var(--paper)',
      boxShadow: 'var(--glow-armed)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tone: "accent",
    tracking: "label"
  }, "Armed \u2014 confirm to fire"), /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: long ? 'long' : 'short',
    variant: "solid"
  }, side)), /*#__PURE__*/React.createElement("div", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-lg)',
      color: 'var(--ink)',
      letterSpacing: 'var(--tracking-tape)'
    }
  }, side, " ", lots, " ", symbol, " @ ", price), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "Rel. SL"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--short)'
    }
  }, sl)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "Rel. TP"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--long)'
    }
  }, tp)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, null, "Target"), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--ink)'
    }
  }, r))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-3)',
      borderRadius: 'var(--radius-chip)',
      background: 'var(--ink-03)',
      border: '1px solid var(--rule)',
      fontSize: 'var(--text-xs)',
      color: grade ? 'var(--ink)' : 'var(--soft)'
    }
  }, grade || 'grading unavailable'), driver && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--tilt-hot)'
    }
  }, driver), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      paddingTop: 'var(--space-3)',
      borderTop: '1px solid var(--rule)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.PadGlyph, {
    button: "LT",
    active: true,
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--muted)'
    }
  }, "held"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--soft)'
    }
  }, "+"), /*#__PURE__*/React.createElement(__ds_scope.PadGlyph, {
    button: "RT",
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--muted)'
    }
  }, holdMs > 0 ? 'hold ' + holdMs + ' ms to fire' : 'to fire'), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.PadGlyph, {
    button: "B",
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--soft)'
    }
  }, "cancel"))));
}
Object.assign(__ds_scope, { ConfirmOverlay });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/hud/ConfirmOverlay.jsx", error: String((e && e.message) || e) }); }

// components/pad/TiltPip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function band(score) {
  if (score >= 0.8) return {
    key: 'scorched',
    label: 'SCORCHED',
    color: 'var(--tilt-scorched)'
  };
  if (score >= 0.6) return {
    key: 'hot',
    label: 'HOT',
    color: 'var(--tilt-hot)'
  };
  if (score >= 0.35) return {
    key: 'warm',
    label: 'WARM',
    color: 'var(--tilt-warm)'
  };
  return {
    key: 'calm',
    label: 'CALM',
    color: 'var(--tilt-calm)'
  };
}
function TiltPip({
  score = 0,
  driver,
  cooldownS,
  layout = 'stack',
  style,
  ...rest
}) {
  const b = band(score);
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: layout === 'row' ? 'row' : 'column',
      alignItems: layout === 'row' ? 'center' : 'flex-start',
      gap: layout === 'row' ? 'var(--space-3)' : 'var(--space-2)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Eyebrow, {
    tracking: "label"
  }, "Tilt"), /*#__PURE__*/React.createElement("i", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: b.color,
      boxShadow: '0 0 8px ' + b.color,
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-label)',
      color: b.color,
      letterSpacing: 'var(--tracking-chip)'
    }
  }, b.label), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 'var(--text-label)',
      color: 'var(--muted)'
    }
  }, score.toFixed(2))), driver && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-tertiary)'
    }
  }, driver), cooldownS != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-xs)',
      color: 'var(--tilt-scorched)'
    }
  }, "opens paused ", cooldownS, "s \xB7 log a memo"));
}
Object.assign(__ds_scope, { band, TiltPip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/pad/TiltPip.jsx", error: String((e && e.message) || e) }); }

// ui_kits/hud/CandleChart.jsx
try { (() => {
// Deterministic fake tape — the real app renders Lightweight Charts.
function makeSeries(n, seed) {
  let s = seed,
    out = [],
    p = 2348;
  const rnd = () => (s = (s * 1103515245 + 12345) % 2147483648) / 2147483648;
  for (let i = 0; i < n; i++) {
    const drift = (rnd() - 0.46) * 2.4;
    const o = p,
      c = p + drift,
      h = Math.max(o, c) + rnd() * 1.1,
      l = Math.min(o, c) - rnd() * 1.1;
    out.push({
      o,
      c,
      h,
      l
    });
    p = c;
  }
  return out;
}
function CandleChart({
  height = 300,
  entry,
  sl,
  tp,
  armed
}) {
  const data = React.useMemo(() => makeSeries(64, 7), []);
  const highs = data.map(d => d.h),
    lows = data.map(d => d.l);
  const hi = Math.max(...highs) + 1.5,
    lo = Math.min(...lows) - 1.5;
  const y = v => (hi - v) / (hi - lo) * height;
  const ema = [];
  data.forEach((d, i) => {
    ema.push(i === 0 ? d.c : ema[i - 1] + (d.c - ema[i - 1]) * (2 / 21));
  });
  const w = 100 / data.length;
  const line = (v, color, label, dash) => v == null ? null : /*#__PURE__*/React.createElement("g", {
    key: label
  }, /*#__PURE__*/React.createElement("line", {
    x1: "0",
    x2: "100",
    y1: y(v),
    y2: y(v),
    stroke: color,
    strokeWidth: "0.6",
    strokeDasharray: dash,
    vectorEffect: "non-scaling-stroke"
  }), /*#__PURE__*/React.createElement("text", {
    x: "99.4",
    y: y(v) - 3,
    fill: color,
    fontFamily: "var(--font-mono)",
    fontSize: "7",
    textAnchor: "end",
    style: {
      fontSize: '9px'
    }
  }, label));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      background: 'var(--ink-02)',
      border: '1px solid var(--rule)',
      borderRadius: 'var(--radius-card)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: '0 0 100 ' + height,
    preserveAspectRatio: "none",
    width: "100%",
    height: height,
    style: {
      display: 'block'
    }
  }, [0.25, 0.5, 0.75].map(f => /*#__PURE__*/React.createElement("line", {
    key: f,
    x1: "0",
    x2: "100",
    y1: height * f,
    y2: height * f,
    stroke: "var(--rule)",
    strokeWidth: "0.5",
    vectorEffect: "non-scaling-stroke"
  })), data.map((d, i) => {
    const up = d.c >= d.o,
      col = up ? 'var(--long)' : 'var(--short)';
    const x = i * w + w / 2;
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("line", {
      x1: x,
      x2: x,
      y1: y(d.h),
      y2: y(d.l),
      stroke: col,
      strokeWidth: "0.5",
      vectorEffect: "non-scaling-stroke"
    }), /*#__PURE__*/React.createElement("rect", {
      x: i * w + w * 0.2,
      width: w * 0.6,
      y: y(Math.max(d.o, d.c)),
      height: Math.max(1, Math.abs(y(d.o) - y(d.c))),
      fill: up ? 'var(--long)' : 'var(--short)',
      opacity: "0.85"
    }));
  }), /*#__PURE__*/React.createElement("polyline", {
    points: ema.map((v, i) => i * w + w / 2 + ',' + y(v)).join(' '),
    fill: "none",
    stroke: "var(--link)",
    strokeWidth: "1",
    vectorEffect: "non-scaling-stroke",
    opacity: "0.8"
  }), line(entry, 'var(--muted)', 'ENTRY', '3 3'), line(tp, 'var(--long)', 'TP', '3 3'), line(sl, 'var(--short)', 'SL', '3 3')), armed && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      boxShadow: 'inset 0 0 0 1.2px var(--accent)',
      borderRadius: 'var(--radius-card)',
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 10,
      top: 8,
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.14em',
      color: 'var(--soft)',
      textTransform: 'uppercase'
    }
  }, "XAUUSD \xB7 M5 \xB7 20 EMA"));
}
Object.assign(window, {
  CandleChart
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/hud/CandleChart.jsx", error: String((e && e.message) || e) }); }

// ui_kits/hud/CopilotDesk.jsx
try { (() => {
const {
  Tabs,
  Panel,
  Eyebrow,
  Badge
} = window.EveningGamepadDesignSystem_0723b4;
const DESK = {
  sentinel: ['London open: volume rising', 'Spread 0.6 — inside cap', 'No high-impact news next 30m', 'Opportunity quality 0.72'],
  news: ['22:30 · US Crude Inventories · medium', '00:00 · FOMC minutes · high — T-15 lock will apply'],
  volman: ['M5 Second Chance Break forming above 2352.4', 'Bias: bullish while above the 20 EMA', 'Setup star: 1 of 3 conditions still pending'],
  advise: ['You have taken 2 of an expected 4 fires tonight.', 'Both were inside the window and at cap.', 'Nothing to fix. Wait for the named setup.'],
  research: ['Session range 11.4 vs 20-day median 9.8', 'Asian session participation above average']
};
function CopilotDesk() {
  const [tab, setTab] = React.useState('sentinel');
  const items = DESK[tab] || [];
  return /*#__PURE__*/React.createElement(Panel, {
    label: "AI desk",
    variant: "offpath",
    tag: /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral"
    }, "Read only \xB7 no order tools"),
    style: {
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    size: "sm",
    hint: "LB / RB",
    items: [{
      id: 'sentinel',
      label: 'Sentinel'
    }, {
      id: 'news',
      label: 'News'
    }, {
      id: 'volman',
      label: 'Volman'
    }, {
      id: 'advise',
      label: 'Advise'
    }, {
      id: 'research',
      label: 'Research'
    }, {
      id: 'memo',
      label: 'Memo',
      disabled: true
    }]
  }), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      marginTop: 4
    }
  }, items.map(t => /*#__PURE__*/React.createElement("li", {
    key: t,
    style: {
      display: 'flex',
      gap: 8,
      fontSize: 13,
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--soft)'
    }
  }, "\xB7"), t))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '8px 10px',
      border: '1px solid var(--rule)',
      borderRadius: 'var(--radius-chip)',
      background: 'var(--ink-02)'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Ask coach"), /*#__PURE__*/React.createElement("input", {
    placeholder: "hold LB + RB to speak\u2026",
    disabled: true,
    style: {
      flex: 1,
      background: 'transparent',
      border: 0,
      color: 'var(--muted)',
      fontFamily: 'var(--font-ui)',
      fontSize: 13,
      outline: 'none'
    }
  })));
}
Object.assign(window, {
  CopilotDesk
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/hud/CopilotDesk.jsx", error: String((e && e.message) || e) }); }

// ui_kits/hud/GameOverlay.jsx
try { (() => {
const {
  Panel,
  Eyebrow,
  Badge,
  PadGlyph,
  Button
} = window.EveningGamepadDesignSystem_0723b4;
const DESTS = [{
  id: 'playbook',
  label: 'Playbook',
  note: '4 setups · M5 Second Chance Break active'
}, {
  id: 'journal',
  label: 'Journal',
  note: "Today, history, trade detail"
}, {
  id: 'system',
  label: 'System',
  note: 'Philosophy and core principles'
}, {
  id: 'reports',
  label: 'Reports',
  note: 'PDF, CSV/JSON export, backup'
}, {
  id: 'settings',
  label: 'Settings',
  note: 'Lot, symbols, clutch deadzone, rumble'
}];
function GameOverlay({
  onClose,
  onGo
}) {
  const [sel, setSel] = React.useState(0);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--overlay-scrim)',
      backdropFilter: 'blur(6px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 620,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "ink"
  }, "Game overlay"), /*#__PURE__*/React.createElement(Badge, {
    tone: "accent",
    variant: "solid"
  }, "Arm cancelled \xB7 new opens locked")), /*#__PURE__*/React.createElement(Panel, {
    padding: "0",
    style: {
      gap: 0,
      overflow: 'hidden'
    }
  }, DESTS.map((d, i) => /*#__PURE__*/React.createElement("button", {
    key: d.id,
    onMouseEnter: () => setSel(i),
    onClick: () => onGo && onGo(d.id),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '14px 16px',
      background: i === sel ? 'var(--ink-05)' : 'transparent',
      border: 0,
      borderLeft: '2px solid ' + (i === sel ? 'var(--accent)' : 'transparent'),
      borderBottom: '1px solid var(--rule)',
      cursor: 'pointer',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 15,
      color: i === sel ? 'var(--ink)' : 'var(--muted)',
      width: 110
    }
  }, d.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, d.note), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto'
    }
  }, i === sel && /*#__PURE__*/React.createElement(PadGlyph, {
    button: "A",
    size: "sm"
  }))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(PadGlyph, {
    button: "D-pad",
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, "select"), /*#__PURE__*/React.createElement(PadGlyph, {
    button: "B",
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, "back"), /*#__PURE__*/React.createElement(PadGlyph, {
    button: "Menu",
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, "exit"), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    size: "sm"
  }, "Flatten"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: onClose
  }, "Close overlay"))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, "Navigation and apply actions cannot emit an open or a modify. An SL/TP edit only stages an armed preview \u2014 LT + RT is still required.")));
}
Object.assign(window, {
  GameOverlay
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/hud/GameOverlay.jsx", error: String((e && e.message) || e) }); }

// ui_kits/hud/HudScreen.jsx
try { (() => {
const DS = window.EveningGamepadDesignSystem_0723b4;
const {
  SessionBar,
  PriceTape,
  SentinelBar,
  AdherenceBadge,
  PositionStrip,
  ConfirmOverlay,
  ClutchMeter,
  TiltPip,
  PadGlyph,
  Button,
  Panel,
  Badge,
  Eyebrow
} = DS;
const RULES = [{
  label: 'Named setup present',
  ok: true
}, {
  label: 'Outside T-15 event window',
  ok: true
}, {
  label: 'Lot at or under cap',
  ok: true
}, {
  label: 'Inside evening window',
  ok: true
}, {
  label: 'Max positions respected',
  ok: true
}];
function PadRail({
  state,
  on
}) {
  const item = (b, label, key, disabled) => /*#__PURE__*/React.createElement("button", {
    key: b,
    disabled: disabled,
    onClick: () => !disabled && on(key),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '6px 10px',
      borderRadius: 'var(--radius-chip)',
      border: '1px solid var(--rule)',
      background: 'var(--ink-02)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1
    }
  }, /*#__PURE__*/React.createElement(PadGlyph, {
    button: b,
    size: "sm",
    active: state === key
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-ui)',
      fontSize: 12,
      color: 'var(--muted)'
    }
  }, label));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Pad"), item('View', state === 'LOCKED' ? 'Unlock' : 'Lock', 'view'), item('LT', 'Clutch', 'clutch', state === 'LOCKED'), item('A', 'Arm buy', 'buy', state !== 'CLUTCH'), item('B', 'Arm sell', 'sell', state !== 'CLUTCH'), item('RT', 'Confirm', 'fire', state !== 'ARMED'), item('X', 'Close', 'close'), item('Y', 'Flatten', 'panic'), item('Menu', 'Overlay', 'menu'));
}
function HudScreen({
  onMenu
}) {
  const [state, setState] = React.useState('LOCKED');
  const [side, setSide] = React.useState(null);
  const [pos, setPos] = React.useState(null);
  const [dollars, setDollars] = React.useState(false);
  const [stoodDown, setStoodDown] = React.useState(3);
  const act = k => {
    if (k === 'view') return setState(s => s === 'LOCKED' ? 'IDLE' : 'LOCKED');
    if (k === 'clutch') return setState(s => s === 'CLUTCH' || s === 'ARMED' ? 'IDLE' : s === 'IDLE' ? 'CLUTCH' : s);
    if (k === 'buy') {
      setSide('BUY');
      return setState('ARMED');
    }
    if (k === 'sell') {
      setSide('SELL');
      return setState('ARMED');
    }
    if (k === 'fire') {
      setPos({
        side,
        symbol: 'XAUUSD',
        lots: '0.05',
        entry: side === 'BUY' ? '2352.80' : '2356.10',
        sl: side === 'BUY' ? '2349.10' : '2359.80',
        tp: side === 'BUY' ? '2361.40' : '2347.50',
        r: 1.32,
        pnlUsd: 66,
        playbook: 'M5 Second Chance Break'
      });
      return setState('IDLE');
    }
    if (k === 'close' || k === 'panic') {
      setPos(null);
      return setState(k === 'panic' ? 'LOCKED' : 'IDLE');
    }
    if (k === 'menu') {
      if (state === 'ARMED') {
        setState('IDLE');
        setStoodDown(n => n + 1);
      }
      return onMenu();
    }
  };
  const clutchVal = state === 'CLUTCH' || state === 'ARMED' ? 0.92 : state === 'LOCKED' ? 0 : 0.12;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      height: '100%'
    }
  }, /*#__PURE__*/React.createElement(SessionBar, {
    clock: "20:15",
    remaining: "3h 15m",
    locked: state === 'LOCKED',
    connected: true,
    right: /*#__PURE__*/React.createElement(Badge, {
      tone: state === 'ARMED' ? 'accent' : 'soft',
      variant: state === 'ARMED' ? 'solid' : 'outline'
    }, "FSM ", state)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'grid',
      gridTemplateColumns: '232px minmax(0,1fr) 340px',
      gap: 16,
      padding: 16,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(PriceTape, {
    last: "2354.28",
    direction: "up",
    bid: "2354.22",
    ask: "2354.28",
    spread: "0.6"
  }), /*#__PURE__*/React.createElement(ClutchMeter, {
    value: clutchVal,
    armed: state === 'ARMED'
  }), /*#__PURE__*/React.createElement(Panel, {
    padding: "12px"
  }, /*#__PURE__*/React.createElement(SentinelBar, {
    quality: "0.72",
    items: [{
      label: 'Spread OK',
      state: 'ok'
    }, {
      label: 'No news < 15m',
      state: 'ok'
    }, {
      label: 'Asian session',
      state: 'ok'
    }, {
      label: 'Range expanding',
      state: 'warn'
    }]
  })), /*#__PURE__*/React.createElement(TiltPip, {
    score: 0.42,
    driver: "six clutch cycles before the last arm"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(window.CandleChart, {
    height: 280,
    armed: state === 'ARMED',
    entry: pos ? 2352.8 : undefined,
    sl: pos ? 2349.1 : undefined,
    tp: pos ? 2361.4 : undefined
  }), state === 'ARMED' && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(ConfirmOverlay, {
    side: side,
    lots: "0.05",
    symbol: "XAUUSD",
    price: "2354.28",
    sl: "-3.70",
    tp: "+8.60",
    r: "2.3R",
    grade: "4 / 5 required rules passed \xB7 M5 Second Chance Break"
  }))), /*#__PURE__*/React.createElement(PositionStrip, {
    position: pos || undefined,
    showDollars: dollars
  }), /*#__PURE__*/React.createElement(PadRail, {
    state: state,
    on: act
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement(AdherenceBadge, {
    rules: RULES,
    stoodDown: stoodDown
  }), /*#__PURE__*/React.createElement(window.CopilotDesk, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setDollars(d => !d)
  }, dollars ? 'Hide dollars' : 'Show dollars'), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'var(--soft)'
    }
  }, "Demo only \xB7 not advice")))));
}
Object.assign(window, {
  HudScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/hud/HudScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/journal/DeckScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const DS = window.EveningGamepadDesignSystem_0723b4;
const {
  Panel,
  Tabs,
  Badge,
  Eyebrow,
  ScoreRadar,
  AxisBar,
  MetricTile,
  TiltPip
} = DS;
function ProcessPanel() {
  const axes = window.EV_DATA.axes;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '360px 1fr',
      gap: 16,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    label: "Process score",
    tag: /*#__PURE__*/React.createElement(Badge, {
      tone: "soft"
    }, "Session close")
  }, /*#__PURE__*/React.createElement(ScoreRadar, {
    size: 230,
    total: 98,
    axes: axes.map(a => ({
      label: a.label,
      value: a.value
    }))
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, "Computed at session close only. There is deliberately no live score to watch.")), /*#__PURE__*/React.createElement(Panel, {
    label: "Axes \u2014 with their working"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 14
    }
  }, axes.map(a => /*#__PURE__*/React.createElement(AxisBar, _extends({
    key: a.label
  }, a)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(MetricTile, {
    label: "Adherence",
    value: "94",
    unit: "%",
    delta: 3,
    sample: 21
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Declined",
    value: "18",
    delta: 5,
    sample: 21,
    note: "stood down during a live condition"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Check-in avg",
    value: "3.8",
    delta: -0.2,
    sample: 21
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Opportunity quality",
    value: "0.61",
    sample: 21,
    note: "session mean"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 16,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    label: "Per playbook"
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ['Playbook', 'n', 'Adherence', 'Avg MFE', 'Avg MAE', 'Efficiency'].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      textAlign: h === 'Playbook' ? 'left' : 'right',
      padding: '6px 0',
      borderBottom: '1px solid var(--rule)',
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--soft)',
      fontWeight: 400
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, [['M5 Second Chance Break', 14, '96%', '2.1R', '0.7R', '68%'], ['M5 Trade-for-failure', 6, '91%', '1.4R', '0.9R', '54%'], ['M5 Double doji break', 3, '83%', '1.1R', '1.0R', '41%']].map(r => /*#__PURE__*/React.createElement("tr", {
    key: r[0]
  }, r.map((c, i) => /*#__PURE__*/React.createElement("td", {
    key: i,
    className: i ? 'ev-num' : '',
    style: {
      textAlign: i ? 'right' : 'left',
      padding: '7px 0',
      borderBottom: '1px solid var(--rule)',
      color: i ? 'var(--muted)' : 'var(--ink)'
    }
  }, c)))))), /*#__PURE__*/React.createElement(Eyebrow, null, "Process figures by default \xB7 outcome sits behind the Outcome tab")), /*#__PURE__*/React.createElement(Panel, {
    label: "Tilt retrospective",
    variant: "offpath"
  }, /*#__PURE__*/React.createElement(TiltPip, {
    score: 0.42,
    driver: "peak driver: lot escalation 1.6x median at 21:44"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 3,
      height: 56,
      marginTop: 6
    }
  }, [0.12, 0.18, 0.22, 0.31, 0.28, 0.44, 0.52, 0.61, 0.47, 0.38, 0.29, 0.21].map((v, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: v * 100 + '%',
      background: v >= 0.6 ? 'var(--tilt-hot)' : v >= 0.35 ? 'var(--tilt-warm)' : 'var(--tilt-calm)',
      opacity: 0.7,
      borderRadius: 2
    }
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, "Retrospective only \u2014 tilt is never an input to the score."))));
}
function OutcomePanel() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(MetricTile, {
    label: "Return",
    value: "+2.4",
    unit: "%",
    delta: 1.1,
    sample: 21,
    tone: "long"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Profit factor",
    value: "1.42",
    delta: 0.2,
    sample: 21
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Average R",
    value: "+0.31",
    delta: 0.08,
    sample: 64,
    tone: "long"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Win rate",
    value: "54",
    unit: "%",
    sample: 64
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Max drawdown",
    value: "-4.8",
    unit: "%",
    sample: 21,
    tone: "short"
  }), /*#__PURE__*/React.createElement(MetricTile, {
    label: "Sharpe",
    lowN: true,
    sample: 21,
    note: "min 30 sessions"
  })), /*#__PURE__*/React.createElement(Panel, {
    label: "Per setup",
    tag: /*#__PURE__*/React.createElement(Badge, {
      tone: "link",
      variant: "solid"
    }, "Demo account")
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ['Volman setup', 'n', 'Return', 'Avg R', 'Win rate'].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      textAlign: h === 'Volman setup' ? 'left' : 'right',
      padding: '6px 0',
      borderBottom: '1px solid var(--rule)',
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--soft)',
      fontWeight: 400
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, [['Second chance break', 14, '+1.8%', '+0.44', '61%'], ['Trade-for-failure', 6, '+0.5%', '+0.19', '50%'], ['Double doji break', 3, '-0.2%', '-0.11', '33%']].map(r => /*#__PURE__*/React.createElement("tr", {
    key: r[0]
  }, r.map((c, i) => /*#__PURE__*/React.createElement("td", {
    key: i,
    className: i ? 'ev-num' : '',
    style: {
      textAlign: i ? 'right' : 'left',
      padding: '7px 0',
      borderBottom: '1px solid var(--rule)',
      color: i ? 'var(--muted)' : 'var(--ink)'
    }
  }, c))))))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, "Demo only \xB7 not advice \xB7 entertainment, not alpha."));
}
function DeckScreen() {
  const [tab, setTab] = React.useState('process');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    value: tab,
    onChange: setTab,
    hint: "money sits behind a deliberate click",
    items: [{
      id: 'process',
      label: 'Process'
    }, {
      id: 'outcome',
      label: 'Outcome'
    }]
  }), tab === 'process' ? /*#__PURE__*/React.createElement(ProcessPanel, null) : /*#__PURE__*/React.createElement(OutcomePanel, null));
}
Object.assign(window, {
  DeckScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/journal/DeckScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/journal/HistoryScreen.jsx
try { (() => {
const DS = window.EveningGamepadDesignSystem_0723b4;
const {
  Panel,
  Badge,
  Eyebrow,
  ProcessHeatmap,
  MistakeTag,
  StatTile,
  Button
} = DS;
const FILTERS = ['Week', 'Month', 'Custom'];
function HistoryScreen() {
  const [sel, setSel] = React.useState('2026-08-06');
  const [period, setPeriod] = React.useState('Month');
  const day = window.EV_DATA.days.find(d => d.date === sel) || {};
  const trades = window.EV_DATA.trades;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '340px 1fr',
      gap: 16,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    label: "Process heatmap",
    tag: /*#__PURE__*/React.createElement(Badge, {
      tone: "soft"
    }, period)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, FILTERS.map(f => /*#__PURE__*/React.createElement(Button, {
    key: f,
    size: "sm",
    variant: f === period ? 'primary' : 'ghost',
    onClick: () => setPeriod(f)
  }, f))), /*#__PURE__*/React.createElement(ProcessHeatmap, {
    days: window.EV_DATA.days,
    selected: sel,
    onSelect: setSel
  }), /*#__PURE__*/React.createElement(Eyebrow, null, "Colour is Process Score. P/L colouring exists only in the Outcome tab.")), /*#__PURE__*/React.createElement(Panel, {
    label: "Mistake trend",
    variant: "offpath"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(MistakeTag, {
    label: "worsened SL",
    count: 4,
    trend: 2
  }), /*#__PURE__*/React.createElement(MistakeTag, {
    label: "chased entry",
    count: 2,
    trend: -1
  }), /*#__PURE__*/React.createElement(MistakeTag, {
    label: "revenge re-entry",
    count: 1
  }), /*#__PURE__*/React.createElement(MistakeTag, {
    label: "skipped review",
    count: 1,
    trend: -2
  }), /*#__PURE__*/React.createElement(MistakeTag, {
    label: "traded before eating",
    count: 3,
    custom: true
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, "One active improvement focus: ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ink)'
    }
  }, "never move a stop against the position.")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    label: 'Day · ' + sel,
    tag: /*#__PURE__*/React.createElement(Badge, {
      tone: day.score == null ? 'soft' : 'long'
    }, day.score == null ? 'no session' : 'score ' + day.score)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "Sessions",
    value: day.score == null ? '0' : '1',
    size: "sm"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Trades",
    value: String(day.trades ?? 0),
    size: "sm"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Readiness",
    value: "4/5",
    size: "sm"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Check-in",
    value: "4 \u2192 4",
    size: "sm"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Process consistency",
    value: "87",
    size: "sm",
    sub: "n=20"
  }))), /*#__PURE__*/React.createElement(Panel, {
    label: "Latest trades",
    tag: /*#__PURE__*/React.createElement(Badge, {
      tone: "link",
      variant: "solid"
    }, "Demo")
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ['Time', 'Symbol', 'Side', 'Playbook', 'Plan', 'R', 'Before', 'During', 'After', ''].map((h, i) => /*#__PURE__*/React.createElement("th", {
    key: i,
    style: {
      textAlign: i > 4 ? 'right' : 'left',
      padding: '6px 0',
      borderBottom: '1px solid var(--rule)',
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--soft)',
      fontWeight: 400
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, trades.map(t => /*#__PURE__*/React.createElement("tr", {
    key: t.cid
  }, /*#__PURE__*/React.createElement("td", {
    className: "ev-num",
    style: {
      padding: '8px 0',
      borderBottom: '1px solid var(--rule)',
      color: 'var(--muted)'
    }
  }, t.time), /*#__PURE__*/React.createElement("td", {
    className: "ev-num",
    style: {
      borderBottom: '1px solid var(--rule)',
      color: 'var(--ink)'
    }
  }, t.symbol), /*#__PURE__*/React.createElement("td", {
    style: {
      borderBottom: '1px solid var(--rule)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: t.side === 'BUY' ? 'long' : 'short'
  }, t.side)), /*#__PURE__*/React.createElement("td", {
    style: {
      borderBottom: '1px solid var(--rule)',
      color: 'var(--muted)'
    }
  }, t.playbook), /*#__PURE__*/React.createElement("td", {
    style: {
      borderBottom: '1px solid var(--rule)'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: t.plan === 'planned' ? 'soft' : 'accent'
  }, t.plan)), /*#__PURE__*/React.createElement("td", {
    className: "ev-num",
    style: {
      textAlign: 'right',
      borderBottom: '1px solid var(--rule)',
      color: t.r >= 0 ? 'var(--long)' : 'var(--short)'
    }
  }, t.r > 0 ? '+' : '', t.r.toFixed(1)), /*#__PURE__*/React.createElement("td", {
    className: "ev-num",
    style: {
      textAlign: 'right',
      borderBottom: '1px solid var(--rule)',
      color: 'var(--muted)'
    }
  }, t.before), /*#__PURE__*/React.createElement("td", {
    className: "ev-num",
    style: {
      textAlign: 'right',
      borderBottom: '1px solid var(--rule)',
      color: 'var(--muted)'
    }
  }, t.during), /*#__PURE__*/React.createElement("td", {
    className: "ev-num",
    style: {
      textAlign: 'right',
      borderBottom: '1px solid var(--rule)',
      color: 'var(--muted)'
    }
  }, t.after), /*#__PURE__*/React.createElement("td", {
    style: {
      textAlign: 'right',
      borderBottom: '1px solid var(--rule)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#replay"
  }, "replay")))))), /*#__PURE__*/React.createElement(Eyebrow, null, "Actual vs Plan \u2014 never a claim that the planned target would have been hit"))));
}
Object.assign(window, {
  HistoryScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/journal/HistoryScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/journal/TodayScreen.jsx
try { (() => {
const DS = window.EveningGamepadDesignSystem_0723b4;
const {
  Panel,
  Eyebrow,
  Badge,
  Button,
  StatTile,
  WorldClocks,
  ReadinessChecklist
} = DS;
function SizeCalc() {
  const [risk, setRisk] = React.useState(50);
  const equity = 10234.56,
    stopDist = 3.7;
  const raw = risk / (stopDist * 100);
  const rounded = Math.min(0.10, Math.floor(raw * 100) / 100);
  return /*#__PURE__*/React.createElement(Panel, {
    label: "Position size",
    tag: /*#__PURE__*/React.createElement(Badge, {
      tone: "soft"
    }, "XAUUSD")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "Equity",
    value: '$' + equity.toLocaleString(),
    size: "sm"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Stop",
    value: "3.70",
    unit: "pts",
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tracking: "label"
  }, "Risk USD"), /*#__PURE__*/React.createElement("input", {
    type: "range",
    min: "10",
    max: "120",
    step: "5",
    value: risk,
    onChange: e => setRisk(+e.target.value),
    style: {
      width: 130,
      accentColor: 'var(--accent)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "ev-num",
    style: {
      fontSize: 13,
      color: 'var(--ink)'
    }
  }, "$", risk)), /*#__PURE__*/React.createElement(StatTile, {
    label: "Requested",
    value: raw.toFixed(3),
    unit: "lots",
    size: "sm",
    tone: "muted"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Broker-rounded",
    value: rounded.toFixed(2),
    unit: "lots",
    size: "sm",
    tone: "accent"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      paddingTop: 10,
      borderTop: '1px solid var(--rule)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm"
  }, "Apply to HUD preview"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--soft)'
    }
  }, "Applying changes the preview only \u2014 LT + RT is still required. Cap 0.10 lot gold.")));
}
function TodayScreen() {
  const [items, setItems] = React.useState([{
    id: 'sleep',
    label: 'Slept enough / energy is there',
    value: true
  }, {
    id: 'calm',
    label: 'Emotionally calm',
    value: true
  }, {
    id: 'focus',
    label: 'No distractions for the next three hours',
    value: false,
    note: 'phone in the other room'
  }, {
    id: 'risk',
    label: "Accept tonight's risk cap",
    value: true
  }, {
    id: 'plan',
    label: 'Plan and news reviewed',
    value: null
  }]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    label: "Market sessions"
  }, /*#__PURE__*/React.createElement(WorldClocks, {
    zones: [{
      city: 'Sydney',
      zone: 'Australia/Sydney',
      time: '23:15',
      open: true
    }, {
      city: 'Tokyo',
      zone: 'Asia/Tokyo',
      time: '22:15',
      open: true
    }, {
      city: 'London',
      zone: 'Europe/London',
      time: '14:15'
    }, {
      city: 'New York',
      zone: 'America/New_York',
      time: '09:15'
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Panel, {
    label: "Readiness",
    tag: /*#__PURE__*/React.createElement(Badge, {
      tone: "soft"
    }, "4 of 5 answered")
  }, /*#__PURE__*/React.createElement(ReadinessChecklist, {
    items: items,
    onToggle: (id, v) => setItems(s => s.map(i => i.id === id ? {
      ...i,
      value: v
    } : i))
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(SizeCalc, null), /*#__PURE__*/React.createElement(Panel, {
    label: "Tonight's analysis",
    tag: /*#__PURE__*/React.createElement(Badge, {
      tone: "soft"
    }, "Player-authored")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      fontSize: 13,
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "ev-eyebrow"
  }, "Thesis"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 4
    }
  }, "Gold holding above the London low; only interested in a second-chance break of 2352.4 while the 20 EMA supports.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 20,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "ev-eyebrow"
  }, "Key levels"), /*#__PURE__*/React.createElement("p", {
    className: "ev-num",
    style: {
      marginTop: 4,
      color: 'var(--ink)',
      fontSize: 12
    }
  }, "2352.4 \xB7 2361.4 \xB7 2347.0")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "ev-eyebrow"
  }, "Invalidation"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 4,
      fontSize: 12
    }
  }, "M5 close below 2347.0")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "ev-eyebrow"
  }, "Event risk"), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 4,
      fontSize: 12
    }
  }, "00:00 FOMC minutes \u2014 T-15 lock"))))))));
}
Object.assign(window, {
  TodayScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/journal/TodayScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/journal/data.js
try { (() => {
window.EV_DATA = {
  days: Array.from({
    length: 35
  }, (_, i) => {
    const d = '2026-08-' + String(i % 31 + 1).padStart(2, '0');
    const pattern = [null, 100, 98, 70, null, 65, 88, 92, 100, 74, null, 96];
    const trades = [0, 0, 4, 0, 0, 5, 2, 3, 0, 1, 0, 3];
    return {
      date: d,
      score: pattern[i % 12],
      trades: trades[i % 12]
    };
  }),
  trades: [{
    cid: '01J8A…7F2',
    time: '21:44',
    symbol: 'XAUUSD',
    side: 'BUY',
    tf: 'M5',
    playbook: 'M5 Second Chance Break',
    plan: 'planned',
    r: 1.8,
    before: 92,
    during: 88,
    after: 100
  }, {
    cid: '01J8A…6C1',
    time: '21:02',
    symbol: 'XAUUSD',
    side: 'SELL',
    tf: 'M5',
    playbook: 'M5 Second Chance Break',
    plan: 'planned',
    r: -1.0,
    before: 88,
    during: 95,
    after: 80
  }, {
    cid: '01J8A…5B9',
    time: '20:31',
    symbol: 'EURUSD',
    side: 'BUY',
    tf: 'M5',
    playbook: 'M5 Trade-for-failure',
    plan: 'planned',
    r: 0.6,
    before: 90,
    during: 70,
    after: 100
  }, {
    cid: '01J8A…4A0',
    time: '19:58',
    symbol: 'XAUUSD',
    side: 'BUY',
    tf: 'M5',
    playbook: '—',
    plan: 'impulsive',
    r: -0.9,
    before: 40,
    during: 55,
    after: 60
  }],
  axes: [{
    label: 'Adherence',
    value: 95,
    weight: 0.30,
    note: '19/20 required rules passed'
  }, {
    label: 'Selectivity',
    value: 100,
    weight: 0.25,
    note: '4 fires inside band [3,5], +2 declines'
  }, {
    label: 'Risk',
    value: 95,
    weight: 0.20,
    note: '19/20 checks — one fire had no SL at entry'
  }, {
    label: 'Preparation',
    value: 100,
    weight: 0.15,
    note: '4/4'
  }, {
    label: 'Review',
    value: 100,
    weight: 0.10,
    note: '4/4'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/journal/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.AxisBar = __ds_scope.AxisBar;

__ds_ns.MetricTile = __ds_scope.MetricTile;

__ds_ns.ScoreRadar = __ds_scope.ScoreRadar;

__ds_ns.AdherenceBadge = __ds_scope.AdherenceBadge;

__ds_ns.ConfirmOverlay = __ds_scope.ConfirmOverlay;

__ds_ns.PositionStrip = __ds_scope.PositionStrip;

__ds_ns.PriceTape = __ds_scope.PriceTape;

__ds_ns.SentinelBar = __ds_scope.SentinelBar;

__ds_ns.SessionBar = __ds_scope.SessionBar;

__ds_ns.MistakeTag = __ds_scope.MistakeTag;

__ds_ns.ProcessHeatmap = __ds_scope.ProcessHeatmap;

__ds_ns.ReadinessChecklist = __ds_scope.ReadinessChecklist;

__ds_ns.WorldClocks = __ds_scope.WorldClocks;

__ds_ns.ClutchMeter = __ds_scope.ClutchMeter;

__ds_ns.PadGlyph = __ds_scope.PadGlyph;

__ds_ns.TiltPip = __ds_scope.TiltPip;

})();
