# EVGamePad — Design System

EVGamePad is a **trading journal you drive with a game controller, reviewed by AI agents.** Traders bind capture actions (log, tag, size, commit) to a gamepad so a fill can be journalled without leaving the chart, and a small crew of agents reads those fills against the trader's own rule set — blocking bad size, tagging setups, and writing the session review.

The visual direction, given in the brief, is **Matrix film × Contra (NES)**: a phosphor-green CRT terminal as the base layer, with arcade sprite colour and hard-edged sprite shadows for moments of action. The result should read like a trading terminal that boots into an arcade cabinet, not like a SaaS dashboard.

## Sources

This system was authored **from the written brief only**. No codebase, Figma file, screenshots, slide deck, or brand assets were provided.

| Source | Status |
|---|---|
| Company description | "EVGamePad — trading journal with AI Agents and GamePad" (chat brief) |
| Art direction note | "matrix film theme + contra game" (chat brief) |
| Codebase / repo | none supplied |
| Figma file | none supplied |
| Logo / brand assets | none supplied |
| Fonts | none supplied — Google Fonts substitutes in use (see Substitutions) |
| Product copy | none supplied — sample copy in the UI kits is written to the tone rules below and should be reviewed |

Everything here is therefore a **proposal**, not a recreation. Values are intentionally specific so they can be argued with.

## Substitutions to confirm

1. **Fonts.** No files were supplied. Standing in: **Press Start 2P** (arcade display), **JetBrains Mono** (all UI, data, body), **VT323** (terminal/agent voice). Loaded from Google Fonts in `tokens/fonts.css`. If EVGamePad has licensed faces, drop the binaries in `assets/fonts/` and replace the `@import` with local `@font-face` rules.
2. **Iconography.** No icon set was supplied. Standing in: **Lucide** (lucide-static 0.417.0, CSS-mask via the `Icon` component) — 2px stroke, square-ish geometry, which sits well with the terminal grid.
3. **Logo.** No mark was supplied, and none has been drawn. Wherever a logo would go, the wordmark **EVGAMEPAD** is set in the display face (`EV` phosphor, `GAMEPAD` arcade red). See `guidelines/brand-wordmark.card.html`. Send a real mark and it will replace the type lockup.
4. **Charts.** No charting source exists, so trade charts are honest placeholders (grid veil + stop/target lines). The equity curve is a token-coloured bar series, not a real chart library.

---

## CONTENT FUNDAMENTALS

**Voice.** A terminal that respects you. Short declaratives, present tense, no hedging and no cheerleading. The product knows the trader's numbers and states them.

**Person.** The product addresses the trader as **you**; agents speak as **I / we** only when they must own a judgement ("I blocked this order"). The company says **we** in marketing, never in the app.

**Casing — the one rule that carries the whole system:**
- **UPPERCASE + 0.18em tracking** for every label, tab, button, badge, column head, nav item. Labels are never sentence case.
- **Sentence case** for every sentence: body copy, notes, agent output, tooltips longer than two words, error messages.
- **Title Case is never used.** Not in headings, not in nav, not in buttons.
- **lowercase** for agent identifiers and tags (`risk-warden`, `fomo`, `orb`) — they are handles, not names.

**Numbers.** R multiples to two decimals with an explicit sign (`+2.40R`, `-1.10R`). Currency with thousands separators and no sign colour on neutral totals. Times are 24-hour (`09:31`). Percentages are whole numbers unless below 10%. Never write "profit" where a number will do.

**Agent output** is written as terminal lines, one clause per line, prefixed `> `:
```
> three contracts on a 0.6R setup — rule 4 caps you at one.
> entry was 41s after the signal bar closed.
> same pattern cost you -4.3R over the last 12 sessions.
```
Agents cite evidence in the same breath as the verdict. They never apologise, never say "great job", never use "just" or "simply".

**Buttons and labels.** Verb first, two words maximum: `LOG TRADE`, `COMMIT SESSION`, `ASK AGENT`, `REBIND`. The one sanctioned piece of arcade language is **INSERT COIN** for the primary marketing CTA, plus **READY PLAYER ONE** as a closing line. Contra/Matrix references stay at that level — no "dodge the bullets", no "there is no spoon", no "wake up".

**Errors** state what happened and what to do, in that order, no exclamation marks: "Broker sync failed. Reconnect the feed and retry the import."

**Emoji: never.** Not in product, not in marketing, not in commit-adjacent UI. Status is carried by colour, a glowing dot, or a lucide glyph. Unicode arrows (`→`) and em dashes are allowed in data strings (`18412.25 → 18461.00`); an em dash for empty values (`—`).

**Numbers over adjectives.** "Median review time 4m 12s, down 71%" beats "dramatically faster". If a claim has no number behind it, cut it.

---

## VISUAL FOUNDATIONS

**Palette.** Near-black surfaces (`#040604` app → `#080C08` panel → `#0D130D` raised → `#131B13` input well), one hero colour — **phosphor green `#00FF41`** — and a small Contra sprite set (red `#E8202A`, orange `#FF8A00`, yellow `#FFD400`, cyan `#22E0FF`, magenta `#FF3DA6`). Neutrals are green-tinted greys so nothing reads as pure grey. Maximum **two** background values in a layout: app black and panel black. Accent colours are for text, keylines and 2px marks — an arcade colour is never a large fill except on the `arcade` button and the pressed pad glyph.

**Colour semantics are locked.** Green = profit and long. Red = loss and short. Magenta = AI agent. Yellow = warning / approaching a limit. Cyan = informational and neutral tags. Nothing else may claim those meanings.

**Type.** Three faces, three jobs. Press Start 2P for arcade display moments only (wordmark, hero, one CTA) — never below 12px, never a paragraph, never more than three lines. JetBrains Mono for everything else, including body copy: this is an all-monospace system, which is what makes a journal of numbers feel native. VT323 at 16px+ for agent output and logs. Body copy 14/1.5, max 64ch. Labels 10–11px uppercase with 0.18em tracking.

**Numerals.** `font-variant-numeric: tabular-nums` on every figure, right-aligned in tables, two decimals on R. Columns must align down the page; that alignment is a brand asset.

**Spacing & layout.** 4px grid with a 2px sub-step for hairline work. Panel padding 16, header strip 8/12, control gap 8, grid gap 16, section padding 56/32. Controls 24/32/40px, table rows 36px, HUD bars 44px, sidebar 216px, content max 1280px. Layout is dense on purpose: a session should fit one screen. Fixed elements: the sidebar, the top session HUD, and the bottom pad-hint bar — the pad hints are always visible, because the pad is always connected.

**Backgrounds.** Flat near-black, never a photograph, never an illustration, and **never a gradient as a hero background**. Texture comes from four veils, one per surface, at 0.4–0.6 opacity: `--veil-scanline` (CRT lines, on terminal/agent panels), `--veil-grid` (24px phosphor graticule, behind charts and hero sections), `--veil-vignette` (darkens hero edges), `--protect-bottom` (bottom protection gradient under text over busy areas). Matrix code rain appears **only** as hero/section texture at ≤0.35 opacity, generated by `ui_kits/site/CodeRain.jsx`. Never put a veil behind numbers.

**Borders.** 1px is the only weight for edges; the default is phosphor at 16% alpha (`--line-hairline`), 42% for focus and emphasis. Panels are separated by hairlines, not by elevation. A **2px left keyline** is the system's selection mark — selected rows, agent turns, toasts, tags, nav items.

**Shadows — two systems, no third.** (1) **Phosphor glow** (`--glow-xs` → `--glow-lg`, plus `--glow-text`) signals state: focus, live, positive P&L, the featured plan. (2) **Sprite shadow** (`2px 2px 0 #000`, never blurred) gives arcade elements their NES weight: the arcade button, pad glyphs, toasts. Inputs use an inset well shadow. A soft grey drop shadow is off-brand and must not appear anywhere.

**Corner radii.** 0 by default. 1–3px exists for the rare case (`--radius-xs/sm/md`); anything above 3px reads as a web app. Pill radius is reserved for two things: status dots and A/B/X/Y face buttons.

**Cards.** Square, `--surface-panel` fill, 1px hairline border, no shadow, no rounding. Optional 34px header strip with an uppercase phosphor title, muted meta, and right-aligned icon actions; optional footer strip on `--black-1`. Content padding 16 (12 in dense contexts, 0 when the card holds rows).

**Transparency & blur.** Used in exactly three places: the modal veil (`rgba(0,0,0,.88)` + 6px blur), the sticky site header (86% black + 6px blur), and alpha fills for selected/hover states (8–32% phosphor). Nothing else is translucent — data must never sit on a blurred surface.

**Hover / press / focus.** Hover = an 8% phosphor wash plus a shift of text from grey to phosphor; never a lighter background than `--black-3`, never a scale. Press = a **1px translate down-right** (the sprite settling), never a scale or shrink. Focus = 2px phosphor ring (`--focus-ring`) plus `--glow-sm`; the ring is never removed. Disabled = `--black-3` fill, `--grey-700` text, no glow.

**Motion.** Mechanical and short: 60–180ms, `steps()` or linear easing, no bounce, no overshoot, no spring. Four sanctioned motions: caret **blink** (1s, steps(1)), CRT **flicker** (4s, idle only), **scan** sweep on panel enter, and a **live pulse** ring on status dots. Toggle knobs snap in 2 steps rather than gliding. Numbers never animate — a P&L figure changes value instantly, because faked motion on money reads as latency.

**Imagery.** There is no photography in this system. If imagery is ever introduced it must be cool-toned, high-contrast, heavily green-graded, with visible grain — treated, never naturalistic. Screenshots of the product itself are the preferred "image".

---

## ICONOGRAPHY

- **Set:** Lucide (substitute — no icon set was supplied). Pinned to `lucide-static@0.417.0` and rendered through the `Icon` component as a **CSS mask**, so every glyph inherits `currentColor` and takes the colour of the row, button or badge it sits in.
- **Delivery:** the `Icon` component fetches each glyph from the pinned CDN once and inlines it as SVG (cross-origin CSS masks are dropped by browsers, so masking is not an option). No icon font, no hand-drawn SVG. For offline/production builds, vendor the used glyphs into `assets/icons/` and point `CDN` in `Icon.jsx` at that folder. No SVGs were hand-drawn for this system, and none should be.
- **Sizes:** 12 / 14 / 16 / 20 / 24px (`xs`–`xl`). 14px inside 24–32px controls, 16px in headers, 20–24px in marketing feature cards. Stroke stays at Lucide's 2px default — never mix a filled set in.
- **Working vocabulary:** `list` (journal), `chart-candlestick` (trade), `bot` (agent), `gamepad-2` (pad), `trending-up` / `trending-down` (P&L), `target` (win rate), `shield` (rules), `timer`, `database`, `terminal`, `filter`, `download`, `plus`, `check`, `x`, `chevron-*`, `arrow-*`, `pencil`, `bell`, `settings`, `send`, `triangle-alert`, `info`.
- **Non-icon glyph vocabulary:** the **gamepad glyph set** (`GamepadKey`) is the product's own icon system — coloured circles for A/B/X/Y, chevron arrows for the d-pad, square shoulder keys for LB/RT/START. Use it, not text, whenever a binding is referenced.
- **Unicode as icons:** `→` in price transitions, `—` for empty values, `>` as the agent line prefix, `·` as a meta separator. That is the whole list.
- **Emoji: never used.**

---

## Index

**Root**
- `styles.css` — the entry point consumers link. `@import` lines only.
- `readme.md` — this file. `SKILL.md` — Agent Skills wrapper. `thumbnail.html` — homepage tile.

**`tokens/`** — `fonts.css` (webfont imports), `colors.css` (ramps + semantic aliases), `typography.css`, `spacing.css`, `effects.css` (radii, borders, glow, sprite shadow, veils, focus, z), `motion.css` (durations, easings, keyframes).

**`guidelines/`** — 22 specimen cards: Colors (phosphor, blacks, arcade, neutrals, trading semantics, status, gamepad), Type (display, core, terminal, HUD labels, numerals), Spacing (scale, control heights, in use), Brand (wordmark, radii, borders, glow, veils, motion, surface stack).

**`components/`** — 19 primitives, each with `.jsx`, `.d.ts`, `.prompt.md`, plus one card per directory:
- `core/` — Button, IconButton, Icon, Card, Badge, Tag, StatTile
- `forms/` — Input, Select, Checkbox, Radio, Switch
- `navigation/` — Tabs
- `feedback/` — Dialog, Toast, Tooltip, MeterBar
- `trading/` — PnLValue, TradeRow
- `agents/` — AgentMessage
- `gamepad/` — GamepadKey

**`ui_kits/`**
- `app/` — journal app click-through: shell, journal, trade detail, agent console, pad bindings (`ui_kits/app/README.md`)
- `site/` — marketing site: landing with code-rain hero, pricing (`ui_kits/site/README.md`)

**`assets/`** — empty. No logos, illustrations or imagery were supplied; nothing has been invented. Fonts load from Google Fonts and icons from the Lucide CDN.

### Intentional additions

No source defined a component inventory, so the set is the standard one plus five brand-specific primitives the product cannot be shown without:

| Addition | Why |
|---|---|
| `Icon` | Wrapper for the substituted Lucide set so glyph delivery is centralised and recolourable |
| `StatTile` | Every journal view opens with a KPI row; without it each screen re-invents the metric cell |
| `MeterBar` | Segmented arcade meter for risk / discipline / confidence — the Contra energy bar, and the reason no smooth progress bar exists here |
| `PnLValue` / `TradeRow` | P&L colour and sign rules must live in one place, and the journal table is the product's core object |
| `AgentMessage` | Agent output has its own typeface, prefix and colour rules; a generic chat bubble would break them |
| `GamepadKey` | Controller bindings are the product's shortcut vocabulary and appear on every screen |

Deliberately **not** built (no source, no current need): Avatar, Breadcrumb, Accordion, Pagination, DatePicker, Table primitives beyond `TradeRow`.
