/* @ds-bundle: {"format":4,"namespace":"EVGamePadDesignSystem_22475d","components":[{"name":"AgentMessage","sourcePath":"components/agents/AgentMessage.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"StatTile","sourcePath":"components/core/StatTile.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"MeterBar","sourcePath":"components/feedback/MeterBar.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"GamepadKey","sourcePath":"components/gamepad/GamepadKey.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"PnLValue","sourcePath":"components/trading/PnLValue.jsx"},{"name":"TradeRow","sourcePath":"components/trading/TradeRow.jsx"}],"sourceHashes":{"components/agents/AgentMessage.jsx":"bb57171ffc45","components/core/Badge.jsx":"abe8728a5a7a","components/core/Button.jsx":"fe701746b881","components/core/Card.jsx":"6457532d0a99","components/core/Icon.jsx":"822f68867987","components/core/IconButton.jsx":"9358547005db","components/core/StatTile.jsx":"2e7ffb10df47","components/core/Tag.jsx":"952f5b12cc6a","components/feedback/Dialog.jsx":"6df7f893ca88","components/feedback/MeterBar.jsx":"f86c8842a078","components/feedback/Toast.jsx":"4ecaa85bcef5","components/feedback/Tooltip.jsx":"781e0e6d86f8","components/forms/Checkbox.jsx":"efbf64610f35","components/forms/Input.jsx":"559a31fb2af4","components/forms/Radio.jsx":"964991d2863d","components/forms/Select.jsx":"65b4c01a9fca","components/forms/Switch.jsx":"212a7b701fa9","components/gamepad/GamepadKey.jsx":"8039eab11f30","components/navigation/Tabs.jsx":"e77670a6ab2a","components/trading/PnLValue.jsx":"a59f10644b53","components/trading/TradeRow.jsx":"7e4830412630","ui_kits/app/AgentConsoleScreen.jsx":"010460dcea0d","ui_kits/app/AppShell.jsx":"203630009043","ui_kits/app/JournalScreen.jsx":"5c16a7c57ce2","ui_kits/app/PadBindingsScreen.jsx":"ef88ecda7879","ui_kits/app/TradeDetailScreen.jsx":"6c482fab964a","ui_kits/app/data.js":"ae03dd86054b","ui_kits/site/CodeRain.jsx":"051268b915f9","ui_kits/site/LandingScreen.jsx":"e16d1e9b23e2","ui_kits/site/PricingScreen.jsx":"55dc39db4093","ui_kits/site/SiteChrome.jsx":"24ab0222c129"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.EVGamePadDesignSystem_22475d = window.EVGamePadDesignSystem_22475d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  neutral: {
    fg: "var(--text-secondary)",
    bg: "var(--black-4)",
    bd: "var(--line-neutral)"
  },
  live: {
    fg: "var(--phos-300)",
    bg: "var(--phos-a16)",
    bd: "var(--line-strong)"
  },
  up: {
    fg: "var(--pnl-up)",
    bg: "var(--pnl-up-bg)",
    bd: "var(--line-strong)"
  },
  down: {
    fg: "var(--pnl-down)",
    bg: "var(--pnl-down-bg)",
    bd: "var(--arcade-red-dim)"
  },
  warn: {
    fg: "var(--arcade-yellow)",
    bg: "rgba(255,212,0,.14)",
    bd: "rgba(255,212,0,.4)"
  },
  info: {
    fg: "var(--arcade-cyan)",
    bg: "rgba(34,224,255,.14)",
    bd: "rgba(34,224,255,.4)"
  },
  agent: {
    fg: "var(--status-agent)",
    bg: "rgba(255,61,166,.14)",
    bd: "rgba(255,61,166,.4)"
  }
};
function Badge({
  tone = "neutral",
  dot,
  children,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-6)",
      height: 18,
      padding: "0 6px",
      background: t.bg,
      color: t.fg,
      border: `1px solid ${t.bd}`,
      borderRadius: "var(--radius-none)",
      fontFamily: "var(--font-core)",
      fontSize: "var(--text-2xs)",
      fontWeight: "var(--weight-bold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), dot ? /*#__PURE__*/React.createElement("i", {
    style: {
      width: 5,
      height: 5,
      borderRadius: "var(--radius-pill)",
      background: t.fg,
      boxShadow: `0 0 6px ${t.fg}`
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  title,
  meta,
  actions,
  footer,
  padding = "var(--panel-pad)",
  tone = "panel",
  scanlines,
  children,
  style,
  ...rest
}) {
  const bg = tone === "raised" ? "var(--surface-raised)" : tone === "well" ? "var(--surface-well)" : "var(--surface-panel)";
  return /*#__PURE__*/React.createElement("section", _extends({
    style: {
      position: "relative",
      background: bg,
      border: "var(--border-hairline)",
      borderRadius: "var(--radius-none)",
      fontFamily: "var(--font-core)",
      color: "var(--text-body)",
      overflow: "hidden",
      ...style
    }
  }, rest), scanlines ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: "var(--veil-scanline)",
      pointerEvents: "none",
      opacity: 0.5
    }
  }) : null, title || actions ? /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "var(--space-12)",
      padding: "var(--space-8) var(--space-12)",
      borderBottom: "var(--border-hairline)",
      minHeight: 34
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: "var(--space-8)",
      minWidth: 0,
      flexShrink: 1
    }
  }, title ? /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-bold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--phos-300)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, title) : null, meta ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--text-muted)",
      letterSpacing: "var(--tracking-wide)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, meta) : null), actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-4)"
    }
  }, actions) : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      padding,
      position: "relative"
    }
  }, children), footer ? /*#__PURE__*/React.createElement("footer", {
    style: {
      padding: "var(--space-8) var(--space-12)",
      borderTop: "var(--border-hairline)",
      fontSize: "var(--text-xs)",
      color: "var(--text-muted)"
    }
  }, footer) : null);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 20,
  xl: 24
};
const CDN = "https://unpkg.com/lucide-static@0.417.0/icons/";
function cache() {
  if (!window.__evIcons) window.__evIcons = {
    svg: {},
    pending: {}
  };
  return window.__evIcons;
}

/** Lucide glyph inlined as SVG so it inherits currentColor at any size. */
function Icon({
  name = "circle",
  size = "md",
  color,
  style,
  className,
  ...rest
}) {
  const px = SIZES[size] || size;
  const c = cache();
  const [svg, setSvg] = React.useState(c.svg[name] || null);
  React.useEffect(() => {
    if (c.svg[name]) {
      setSvg(c.svg[name]);
      return;
    }
    let live = true;
    const p = c.pending[name] || (c.pending[name] = fetch(CDN + name + ".svg").then(r => r.ok ? r.text() : "").then(t => {
      const body = t.replace(/<!--[\s\S]*?-->/g, "").replace(/^[\s\S]*?<svg[^>]*>/, "").replace(/<\/svg>[\s\S]*$/, "");
      c.svg[name] = body;
      return body;
    }).catch(() => ""));
    p.then(body => {
      if (live) setSvg(body);
    });
    return () => {
      live = false;
    };
  }, [name]);
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "img",
    "aria-label": name,
    "data-icon": name,
    className: className,
    style: {
      display: "inline-flex",
      width: px,
      height: px,
      flex: "0 0 auto",
      color: color || "currentColor",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: px,
    height: px,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    dangerouslySetInnerHTML: {
      __html: svg || ""
    }
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/agents/AgentMessage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function AgentMessage({
  author = "agent",
  name,
  model,
  time,
  confidence,
  streaming,
  children,
  style,
  ...rest
}) {
  const isUser = author === "user";
  const accent = isUser ? "var(--phos-400)" : "var(--status-agent)";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "grid",
      gridTemplateColumns: "22px 1fr",
      gap: "var(--space-8)",
      padding: "var(--space-12)",
      background: isUser ? "transparent" : "var(--black-2)",
      borderLeft: `2px solid ${accent}`,
      fontFamily: "var(--font-core)",
      minWidth: 0,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 22,
      height: 22,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      border: `1px solid ${accent}`,
      color: accent,
      background: "var(--black-1)"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: isUser ? "user" : "bot",
    size: "sm"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-6)",
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-8)",
      fontSize: "var(--text-2xs)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: accent,
      fontWeight: "var(--weight-bold)"
    }
  }, name || (isUser ? "you" : "agent")), model ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-muted)"
    }
  }, model) : null, confidence != null ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "agent"
  }, "conf ", confidence) : null, time ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-disabled)",
      marginLeft: "auto"
    }
  }, time) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: isUser ? "var(--font-core)" : "var(--font-terminal)",
      fontSize: isUser ? "var(--text-sm)" : "var(--text-lg)",
      lineHeight: isUser ? "var(--leading-normal)" : "var(--leading-snug)",
      overflowWrap: "anywhere",
      color: isUser ? "var(--text-body)" : "var(--text-terminal)"
    }
  }, children, streaming ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-block",
      width: 7,
      height: "1em",
      marginLeft: 3,
      background: "var(--phos-400)",
      verticalAlign: "text-bottom",
      animation: "ev-blink 1s steps(1,end) infinite"
    }
  }) : null)));
}
Object.assign(__ds_scope, { AgentMessage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/agents/AgentMessage.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const HEIGHTS = {
  sm: "var(--control-h-sm)",
  md: "var(--control-h-md)",
  lg: "var(--control-h-lg)"
};
const FONTS = {
  sm: "var(--text-xs)",
  md: "var(--text-sm)",
  lg: "var(--text-md)"
};
const VARIANTS = {
  primary: {
    base: {
      background: "var(--phos-400)",
      color: "var(--text-inverse)",
      border: "1px solid var(--phos-400)",
      boxShadow: "var(--glow-sm)"
    },
    hover: {
      background: "var(--phos-300)",
      borderColor: "var(--phos-300)",
      boxShadow: "var(--glow-md)"
    }
  },
  secondary: {
    base: {
      background: "transparent",
      color: "var(--phos-300)",
      border: "1px solid var(--line-strong)"
    },
    hover: {
      background: "var(--phos-a16)",
      borderColor: "var(--phos-400)",
      color: "var(--phos-200)"
    }
  },
  ghost: {
    base: {
      background: "transparent",
      color: "var(--text-secondary)",
      border: "1px solid transparent"
    },
    hover: {
      background: "var(--surface-hover)",
      color: "var(--phos-300)"
    }
  },
  danger: {
    base: {
      background: "transparent",
      color: "var(--arcade-red)",
      border: "1px solid var(--arcade-red-dim)"
    },
    hover: {
      background: "rgba(232,32,42,.16)",
      borderColor: "var(--arcade-red)",
      boxShadow: "var(--glow-red)"
    }
  },
  arcade: {
    base: {
      background: "var(--arcade-red)",
      color: "#fff",
      border: "1px solid var(--black-0)",
      boxShadow: "var(--sprite-shadow)",
      fontFamily: "var(--font-display)",
      letterSpacing: 0
    },
    hover: {
      background: "var(--arcade-orange)"
    }
  }
};
function Button({
  variant = "primary",
  size = "md",
  icon,
  iconAfter,
  disabled,
  fullWidth,
  children,
  style,
  onClick,
  type = "button",
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [down, setDown] = React.useState(false);
  const v = VARIANTS[variant] || VARIANTS.primary;
  const s = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--space-8)",
    height: HEIGHTS[size],
    padding: `0 ${size === "sm" ? 8 : 14}px`,
    width: fullWidth ? "100%" : undefined,
    fontFamily: variant === "arcade" ? "var(--font-display)" : "var(--font-core)",
    fontSize: variant === "arcade" ? "var(--display-sm)" : FONTS[size],
    fontWeight: variant === "arcade" ? 400 : "var(--weight-bold)",
    letterSpacing: variant === "arcade" ? 0 : "var(--tracking-wide)",
    textTransform: "uppercase",
    borderRadius: "var(--radius-none)",
    cursor: disabled ? "not-allowed" : "pointer",
    whiteSpace: "nowrap",
    transition: "var(--transition-control)",
    transform: down && !disabled ? "translate(1px,1px)" : "none",
    ...v.base,
    ...(hover && !disabled ? v.hover : null),
    ...(disabled ? {
      background: "var(--black-3)",
      color: "var(--text-disabled)",
      borderColor: "var(--line-neutral)",
      boxShadow: "none"
    } : null),
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: s,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setDown(false);
    },
    onMouseDown: () => setDown(true),
    onMouseUp: () => setDown(false)
  }, rest), icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === "lg" ? "md" : "sm"
  }) : null, children, iconAfter ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconAfter,
    size: size === "lg" ? "md" : "sm"
  }) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const HEIGHTS = {
  sm: 24,
  md: 32,
  lg: 40
};
function IconButton({
  icon,
  size = "md",
  variant = "ghost",
  active,
  disabled,
  label,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const px = HEIGHTS[size];
  const outlined = variant === "outline";
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label || icon,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: px,
      height: px,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: active ? "var(--surface-selected)" : hover && !disabled ? "var(--surface-hover)" : "transparent",
      color: disabled ? "var(--text-disabled)" : active || hover ? "var(--phos-300)" : "var(--text-secondary)",
      border: outlined ? "1px solid var(--line-hairline)" : "1px solid transparent",
      borderRadius: "var(--radius-none)",
      cursor: disabled ? "not-allowed" : "pointer",
      transition: "var(--transition-control)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === "sm" ? "sm" : size === "lg" ? "lg" : "md"
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/StatTile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatTile({
  label,
  value,
  delta,
  tone = "neutral",
  icon,
  sub,
  style,
  ...rest
}) {
  const c = tone === "up" ? "var(--pnl-up)" : tone === "down" ? "var(--pnl-down)" : "var(--text-primary)";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: "var(--surface-panel)",
      border: "var(--border-hairline)",
      padding: "var(--space-12)",
      display: "grid",
      gap: "var(--space-6)",
      fontFamily: "var(--font-core)",
      minWidth: 0,
      overflow: "hidden",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-6)",
      color: "var(--text-muted)",
      fontSize: "var(--text-2xs)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase"
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: "xs"
  }) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, label)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: "var(--space-8)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-data)",
      fontSize: "clamp(15px, 2.1vw, 20px)",
      fontWeight: "var(--weight-bold)",
      color: c,
      fontVariantNumeric: "tabular-nums",
      whiteSpace: "nowrap",
      textShadow: tone === "up" ? "var(--glow-text)" : "none"
    }
  }, value), delta ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: tone === "down" ? "var(--pnl-down)" : "var(--phos-500)",
      fontVariantNumeric: "tabular-nums"
    }
  }, delta) : null), sub ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--text-muted)"
    }
  }, sub) : null);
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tag({
  children,
  onRemove,
  color = "var(--phos-400)",
  selected,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-6)",
      height: 20,
      padding: "0 6px 0 5px",
      background: selected ? "var(--surface-selected)" : hover && onClick ? "var(--surface-hover)" : "transparent",
      border: "1px solid var(--line-hairline)",
      borderLeft: `2px solid ${color}`,
      color: selected ? "var(--phos-200)" : "var(--text-secondary)",
      fontFamily: "var(--font-core)",
      fontSize: "var(--text-2xs)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      whiteSpace: "nowrap",
      cursor: onClick ? "pointer" : "default",
      transition: "var(--transition-control)",
      ...style
    }
  }, rest), children, onRemove ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    "aria-label": "Remove tag",
    style: {
      display: "inline-flex",
      background: "none",
      border: 0,
      padding: 0,
      color: "inherit",
      cursor: "pointer",
      opacity: 0.7
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: "xs"
  })) : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Dialog({
  open = true,
  title,
  subtitle,
  footer,
  onClose,
  width = 480,
  tone = "default",
  children,
  style,
  ...rest
}) {
  if (!open) return null;
  const accent = tone === "danger" ? "var(--arcade-red)" : "var(--phos-400)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: "var(--z-overlay)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--surface-overlay)",
      backdropFilter: "var(--blur-overlay)",
      fontFamily: "var(--font-core)"
    }
  }, /*#__PURE__*/React.createElement("div", _extends({
    role: "dialog",
    "aria-modal": "true",
    style: {
      width,
      maxWidth: "92%",
      background: "var(--surface-panel)",
      border: `1px solid ${accent}`,
      boxShadow: tone === "danger" ? "var(--glow-red)" : "var(--glow-md)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: "var(--space-12)",
      padding: "var(--space-12)",
      borderBottom: "var(--border-hairline)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-bold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: accent
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: "var(--text-xs)",
      color: "var(--text-muted)"
    }
  }, subtitle) : null), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    size: "sm",
    label: "Close",
    onClick: onClose
  }) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-16) var(--space-12)",
      fontSize: "var(--text-sm)",
      color: "var(--text-body)",
      lineHeight: "var(--leading-normal)"
    }
  }, children), footer ? /*#__PURE__*/React.createElement("footer", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: "var(--space-8)",
      padding: "var(--space-12)",
      borderTop: "var(--border-hairline)",
      background: "var(--black-1)"
    }
  }, footer) : null));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/MeterBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function MeterBar({
  value = 0,
  max = 100,
  label,
  segments = 20,
  tone = "phos",
  showValue,
  style,
  ...rest
}) {
  const pct = Math.max(0, Math.min(1, max ? value / max : 0));
  const filled = Math.round(pct * segments);
  const color = tone === "danger" ? "var(--arcade-red)" : tone === "warn" ? "var(--arcade-yellow)" : tone === "info" ? "var(--arcade-cyan)" : "var(--phos-400)";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "grid",
      gap: "var(--space-4)",
      fontFamily: "var(--font-core)",
      minWidth: 0,
      ...style
    }
  }, rest), label || showValue ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: "var(--text-2xs)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement("span", null, label), showValue ? /*#__PURE__*/React.createElement("span", {
    style: {
      color,
      fontVariantNumeric: "tabular-nums"
    }
  }, value, "/", max) : null) : null, /*#__PURE__*/React.createElement("div", {
    role: "meter",
    "aria-valuenow": value,
    "aria-valuemax": max,
    style: {
      display: "flex",
      gap: 2,
      height: 8,
      background: "var(--surface-well)",
      border: "1px solid var(--line-hairline)",
      padding: 1
    }
  }, Array.from({
    length: segments
  }).map((_, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      flex: 1,
      background: i < filled ? color : "var(--black-5)",
      boxShadow: i < filled ? `0 0 4px ${color}` : "none",
      transition: "background-color var(--dur-fast) var(--ease-step-2)"
    }
  }))));
}
Object.assign(__ds_scope, { MeterBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/MeterBar.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const TONES = {
  success: {
    c: "var(--phos-400)",
    icon: "check"
  },
  error: {
    c: "var(--arcade-red)",
    icon: "triangle-alert"
  },
  warn: {
    c: "var(--arcade-yellow)",
    icon: "alert-circle"
  },
  info: {
    c: "var(--arcade-cyan)",
    icon: "info"
  },
  agent: {
    c: "var(--status-agent)",
    icon: "bot"
  }
};
function Toast({
  tone = "info",
  title,
  message,
  action,
  onClose,
  style,
  ...rest
}) {
  const t = TONES[tone] || TONES.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: "var(--space-8)",
      minWidth: 280,
      maxWidth: 420,
      padding: "var(--space-8) var(--space-8) var(--space-8) var(--space-12)",
      background: "var(--black-2)",
      border: "var(--border-hairline)",
      borderLeft: `2px solid ${t.c}`,
      boxShadow: "var(--sprite-shadow-lg)",
      fontFamily: "var(--font-core)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: "sm",
    style: {
      color: t.c,
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 3,
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-bold)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      color: t.c
    }
  }, title), message ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-xs)",
      color: "var(--text-secondary)",
      lineHeight: "var(--leading-snug)"
    }
  }, message) : null, action ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 4
    }
  }, action) : null), onClose ? /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    size: "sm",
    label: "Dismiss",
    onClick: onClose
  }) : null);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tooltip({
  label,
  shortcut,
  placement = "top",
  children,
  style,
  ...rest
}) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: {
      bottom: "calc(100% + 6px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    bottom: {
      top: "calc(100% + 6px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    left: {
      right: "calc(100% + 6px)",
      top: "50%",
      transform: "translateY(-50%)"
    },
    right: {
      left: "calc(100% + 6px)",
      top: "50%",
      transform: "translateY(-50%)"
    }
  }[placement];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, rest), children, show ? /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      ...pos,
      zIndex: "var(--z-dropdown)",
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-6)",
      padding: "3px 6px",
      background: "var(--black-0)",
      border: "var(--border-strong)",
      color: "var(--phos-200)",
      fontFamily: "var(--font-core)",
      fontSize: "var(--text-2xs)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      whiteSpace: "nowrap",
      boxShadow: "var(--glow-xs)",
      pointerEvents: "none"
    }
  }, label, shortcut ? /*#__PURE__*/React.createElement("kbd", {
    style: {
      fontFamily: "var(--font-core)",
      color: "var(--text-muted)",
      border: "1px solid var(--line-neutral)",
      padding: "0 3px"
    }
  }, shortcut) : null) : null);
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Checkbox({
  label,
  checked,
  onChange,
  disabled,
  description,
  style,
  id,
  ...rest
}) {
  const boxId = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: boxId,
    style: {
      display: "inline-flex",
      alignItems: description ? "flex-start" : "center",
      gap: "var(--space-8)",
      fontFamily: "var(--font-core)",
      fontSize: "var(--text-sm)",
      color: disabled ? "var(--text-disabled)" : "var(--text-body)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.6 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: boxId,
    type: "checkbox",
    checked: !!checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14,
      height: 14,
      flex: "0 0 14px",
      marginTop: description ? 2 : 0,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: checked ? "var(--phos-400)" : "var(--surface-well)",
      border: `1px solid ${checked ? "var(--phos-400)" : "var(--line-strong)"}`,
      boxShadow: checked ? "var(--glow-xs)" : "none",
      color: "var(--black-1)",
      transition: "var(--transition-control)"
    }
  }, checked ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 10
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "grid",
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", null, label), description ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--text-muted)"
    }
  }, description) : null));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Input({
  label,
  hint,
  error,
  icon,
  suffix,
  size = "md",
  align = "left",
  value,
  onChange,
  placeholder,
  disabled,
  readOnly,
  type = "text",
  style,
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const h = size === "sm" ? "var(--control-h-sm)" : size === "lg" ? "var(--control-h-lg)" : "var(--control-h-md)";
  const inputId = id || React.useId();
  const borderColor = error ? "var(--arcade-red)" : focus ? "var(--phos-400)" : "var(--line-hairline)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-6)",
      fontFamily: "var(--font-core)",
      minWidth: 0,
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: "var(--text-2xs)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-8)",
      height: h,
      minWidth: 0,
      padding: "0 var(--space-8)",
      background: "var(--surface-well)",
      border: `1px solid ${borderColor}`,
      borderRadius: "var(--radius-none)",
      boxShadow: focus ? "var(--glow-sm)" : "var(--inset-well)",
      opacity: disabled ? 0.5 : 1,
      transition: "var(--transition-control)"
    }
  }, icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: "sm",
    style: {
      color: focus ? "var(--phos-400)" : "var(--text-muted)"
    }
  }) : null, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    disabled: disabled,
    readOnly: readOnly,
    size: 1,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      width: "100%",
      background: "transparent",
      border: 0,
      outline: "none",
      color: "var(--text-body)",
      fontFamily: "var(--font-data)",
      fontSize: size === "sm" ? "var(--text-xs)" : "var(--text-sm)",
      textAlign: align,
      fontVariantNumeric: "tabular-nums"
    }
  }, rest)), suffix ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--text-muted)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase"
    }
  }, suffix) : null), error || hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      color: error ? "var(--arcade-red)" : "var(--text-muted)"
    }
  }, error || hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Radio({
  label,
  checked,
  onChange,
  name,
  value,
  disabled,
  description,
  style,
  id,
  ...rest
}) {
  const radioId = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: radioId,
    style: {
      display: "inline-flex",
      alignItems: description ? "flex-start" : "center",
      gap: "var(--space-8)",
      fontFamily: "var(--font-core)",
      fontSize: "var(--text-sm)",
      color: disabled ? "var(--text-disabled)" : "var(--text-body)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.6 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: radioId,
    type: "radio",
    name: name,
    value: value,
    checked: !!checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 14,
      height: 14,
      flex: "0 0 14px",
      marginTop: description ? 2 : 0,
      borderRadius: "var(--radius-pill)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--surface-well)",
      border: `1px solid ${checked ? "var(--phos-400)" : "var(--line-strong)"}`,
      boxShadow: checked ? "var(--glow-xs)" : "none",
      transition: "var(--transition-control)"
    }
  }, checked ? /*#__PURE__*/React.createElement("i", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "var(--radius-pill)",
      background: "var(--phos-400)"
    }
  }) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "grid",
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", null, label), description ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--text-muted)"
    }
  }, description) : null));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  options = [],
  value,
  onChange,
  size = "md",
  disabled,
  hint,
  style,
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const selectId = id || React.useId();
  const h = size === "sm" ? "var(--control-h-sm)" : size === "lg" ? "var(--control-h-lg)" : "var(--control-h-md)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-6)",
      fontFamily: "var(--font-core)",
      minWidth: 0,
      ...style
    }
  }, label ? /*#__PURE__*/React.createElement("label", {
    htmlFor: selectId,
    style: {
      fontSize: "var(--text-2xs)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: h,
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: selectId,
    value: value,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: "100%",
      minWidth: 0,
      height: "100%",
      appearance: "none",
      background: "var(--surface-well)",
      color: "var(--text-body)",
      border: `1px solid ${focus ? "var(--phos-400)" : "var(--line-hairline)"}`,
      borderRadius: "var(--radius-none)",
      boxShadow: focus ? "var(--glow-sm)" : "var(--inset-well)",
      padding: "0 26px 0 var(--space-8)",
      fontFamily: "var(--font-core)",
      fontSize: size === "sm" ? "var(--text-xs)" : "var(--text-sm)",
      letterSpacing: "var(--tracking-wide)",
      outline: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      transition: "var(--transition-control)"
    }
  }, rest), options.map(o => {
    const opt = typeof o === "string" ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value,
      style: {
        background: "var(--black-2)"
      }
    }, opt.label);
  })), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: "sm",
    style: {
      position: "absolute",
      right: 8,
      top: "50%",
      transform: "translateY(-50%)",
      color: "var(--text-muted)",
      pointerEvents: "none"
    }
  })), hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      color: "var(--text-muted)"
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Switch({
  label,
  checked,
  onChange,
  disabled,
  size = "md",
  style,
  id,
  ...rest
}) {
  const swId = id || React.useId();
  const w = size === "sm" ? 26 : 34,
    h = size === "sm" ? 14 : 18,
    knob = h - 6;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: swId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-8)",
      fontFamily: "var(--font-core)",
      fontSize: "var(--text-sm)",
      color: "var(--text-body)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.6 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: swId,
    type: "checkbox",
    role: "switch",
    checked: !!checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "relative",
      width: w,
      height: h,
      flex: `0 0 ${w}px`,
      background: checked ? "var(--phos-a32)" : "var(--surface-well)",
      border: `1px solid ${checked ? "var(--phos-400)" : "var(--line-strong)"}`,
      boxShadow: checked ? "var(--glow-xs)" : "none",
      transition: "var(--transition-control)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      position: "absolute",
      top: 2,
      left: checked ? w - knob - 4 : 2,
      width: knob,
      height: knob,
      background: checked ? "var(--phos-400)" : "var(--grey-500)",
      transition: `left var(--dur-fast) var(--ease-step-2), background-color var(--dur-fast) linear`
    }
  })), label ? /*#__PURE__*/React.createElement("span", null, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/gamepad/GamepadKey.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const FACE = {
  a: "var(--pad-a)",
  b: "var(--pad-b)",
  x: "var(--pad-x)",
  y: "var(--pad-y)"
};
const DIR = {
  up: "chevron-up",
  down: "chevron-down",
  left: "chevron-left",
  right: "chevron-right"
};
function GamepadKey({
  button = "a",
  label,
  size = "md",
  pressed,
  style,
  ...rest
}) {
  const key = String(button).toLowerCase();
  const px = size === "sm" ? 18 : size === "lg" ? 28 : 22;
  const face = FACE[key];
  const dir = DIR[key];
  const color = face || "var(--pad-shoulder)";
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-6)",
      fontFamily: "var(--font-core)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: face || dir ? px : "auto",
      height: px,
      minWidth: px,
      padding: face || dir ? 0 : "0 6px",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      borderRadius: face ? "var(--radius-pill)" : "var(--radius-sm)",
      border: `1px solid ${color}`,
      color: pressed ? "var(--black-1)" : color,
      background: pressed ? color : "var(--black-3)",
      boxShadow: pressed ? `0 0 8px ${color}` : "var(--sprite-shadow)",
      fontSize: size === "sm" ? "var(--text-2xs)" : "var(--text-xs)",
      fontWeight: "var(--weight-bold)",
      letterSpacing: "var(--tracking-wide)",
      textTransform: "uppercase",
      transform: pressed ? "translate(1px,1px)" : "none",
      transition: "var(--transition-control)"
    }
  }, dir ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: dir,
    size: size === "sm" ? "xs" : "sm"
  }) : String(button).toUpperCase()), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-secondary)"
    }
  }, label) : null);
}
Object.assign(__ds_scope, { GamepadKey });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/gamepad/GamepadKey.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tabs({
  tabs = [],
  value,
  onChange,
  variant = "underline",
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(null);
  const seg = variant === "segmented";
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: "flex",
      alignItems: "stretch",
      gap: seg ? 0 : "var(--space-16)",
      borderBottom: seg ? "none" : "var(--border-hairline)",
      border: seg ? "var(--border-hairline)" : undefined,
      fontFamily: "var(--font-core)",
      ...style
    }
  }, rest), tabs.map(t => {
    const tab = typeof t === "string" ? {
      value: t,
      label: t
    } : t;
    const active = tab.value === value;
    const hot = hover === tab.value;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.value,
      role: "tab",
      "aria-selected": active,
      onClick: () => onChange && onChange(tab.value),
      onMouseEnter: () => setHover(tab.value),
      onMouseLeave: () => setHover(null),
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: "var(--space-6)",
        height: seg ? 26 : 32,
        padding: seg ? "0 10px" : "0 2px",
        background: seg ? active ? "var(--surface-selected)" : hot ? "var(--surface-hover)" : "transparent" : "transparent",
        border: 0,
        borderRight: seg ? "var(--border-hairline)" : 0,
        borderBottom: seg ? 0 : `2px solid ${active ? "var(--phos-400)" : "transparent"}`,
        color: active ? "var(--phos-300)" : hot ? "var(--text-body)" : "var(--text-muted)",
        fontSize: "var(--text-xs)",
        fontWeight: "var(--weight-bold)",
        letterSpacing: "var(--tracking-caps)",
        textTransform: "uppercase",
        cursor: "pointer",
        transition: "var(--transition-control)",
        textShadow: active ? "var(--glow-text)" : "none"
      }
    }, tab.icon ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: tab.icon,
      size: "sm"
    }) : null, tab.label, tab.count != null ? /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-muted)",
        fontVariantNumeric: "tabular-nums"
      }
    }, tab.count) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/trading/PnLValue.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function PnLValue({
  value,
  unit = "R",
  size = "md",
  showSign = true,
  showArrow,
  precision = 2,
  style,
  ...rest
}) {
  const n = typeof value === "number" ? value : parseFloat(value);
  const dir = n > 0 ? "up" : n < 0 ? "down" : "flat";
  const color = dir === "up" ? "var(--pnl-up)" : dir === "down" ? "var(--pnl-down)" : "var(--pnl-flat)";
  const fs = {
    xs: "var(--text-xs)",
    sm: "var(--text-sm)",
    md: "var(--text-lg)",
    lg: "var(--text-2xl)",
    xl: "var(--text-4xl)"
  }[size] || size;
  const text = (showSign && n > 0 ? "+" : "") + (isNaN(n) ? String(value) : n.toFixed(precision));
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "var(--space-4)",
      fontFamily: "var(--font-data)",
      fontSize: fs,
      fontWeight: "var(--weight-bold)",
      color,
      fontVariantNumeric: "tabular-nums",
      letterSpacing: "var(--tracking-tight)",
      textShadow: dir === "up" ? "var(--glow-text)" : dir === "down" ? "0 0 6px rgba(232,32,42,.5)" : "none",
      ...style
    }
  }, rest), showArrow && dir !== "flat" ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: dir === "up" ? "arrow-up-right" : "arrow-down-right",
    size: "sm"
  }) : null, text, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "0.7em",
      opacity: 0.8
    }
  }, unit));
}
Object.assign(__ds_scope, { PnLValue });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trading/PnLValue.jsx", error: String((e && e.message) || e) }); }

// components/trading/TradeRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TradeRow({
  time,
  symbol,
  side = "long",
  size,
  entry,
  exit,
  result,
  tags = [],
  status,
  selected,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const sideColor = side === "short" ? "var(--side-short)" : "var(--side-long)";
  const cell = {
    fontFamily: "var(--font-data)",
    fontSize: "var(--text-xs)",
    color: "var(--text-secondary)",
    fontVariantNumeric: "tabular-nums",
    minWidth: 0,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "row",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(0,52px) minmax(0,74px) 40px minmax(0,84px) minmax(34px,1.2fr) minmax(58px,90px) 20px",
      alignItems: "center",
      gap: "var(--space-8)",
      minHeight: "var(--row-h)",
      padding: "4px 0",
      paddingLeft: "var(--space-12)",
      paddingRight: "var(--space-12)",
      borderBottom: "var(--border-hairline)",
      borderLeft: `2px solid ${selected ? "var(--phos-400)" : "transparent"}`,
      background: selected ? "var(--surface-selected)" : hover ? "var(--surface-hover)" : "transparent",
      cursor: onClick ? "pointer" : "default",
      transition: "var(--transition-control)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      ...cell,
      color: "var(--text-muted)"
    }
  }, time), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-core)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-bold)",
      color: "var(--text-body)",
      letterSpacing: "var(--tracking-wide)",
      minWidth: 0,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, symbol), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-core)",
      fontSize: "var(--text-2xs)",
      fontWeight: "var(--weight-bold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: sideColor,
      minWidth: 0,
      overflow: "hidden"
    }
  }, side), /*#__PURE__*/React.createElement("span", {
    style: {
      ...cell,
      whiteSpace: "normal",
      lineHeight: 1.15,
      textOverflow: "clip"
    }
  }, entry, exit ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-disabled)"
    }
  }, " \u2192 "), exit) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: "var(--space-4)",
      minWidth: 0,
      overflow: "hidden"
    }
  }, tags.slice(0, 3).map(t => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: t.label || t,
    color: t.color
  }, t.label || t)), status ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: status === "open" ? "live" : "neutral",
    dot: status === "open"
  }, status) : null), /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 0,
      display: "flex",
      justifyContent: "flex-end",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.PnLValue, {
    value: result,
    size: "sm"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      color: hover ? "var(--phos-400)" : "var(--text-disabled)",
      display: "flex",
      justifyContent: "flex-end"
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: "sm"
  })));
}
Object.assign(__ds_scope, { TradeRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/trading/TradeRow.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/AgentConsoleScreen.jsx
try { (() => {
(function () {
  const {
    Card,
    Badge,
    Button,
    IconButton,
    Input,
    Switch,
    AgentMessage,
    MeterBar,
    Tabs,
    GamepadKey
  } = window.EVGamePadDesignSystem_22475d;
  function AgentRow({
    agent,
    active,
    onClick
  }) {
    const [hover, setHover] = React.useState(false);
    const tone = agent.state === "live" ? "live" : agent.state === "idle" ? "neutral" : "neutral";
    return /*#__PURE__*/React.createElement("button", {
      onClick: onClick,
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        textAlign: "left",
        display: "grid",
        gap: 4,
        padding: "10px 12px",
        width: "100%",
        border: 0,
        borderBottom: "1px solid var(--line-hairline)",
        borderLeft: `2px solid ${active ? "var(--status-agent)" : "transparent"}`,
        background: active ? "rgba(255,61,166,.10)" : hover ? "var(--surface-hover)" : "transparent",
        cursor: "pointer",
        fontFamily: "var(--font-core)",
        transition: "var(--transition-control)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: ".12em",
        textTransform: "uppercase",
        color: active ? "var(--status-agent)" : "var(--text-body)"
      }
    }, agent.id), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        color: "var(--text-disabled)",
        fontFamily: "var(--font-data)"
      }
    }, agent.model), /*#__PURE__*/React.createElement(Badge, {
      tone: tone,
      dot: agent.state === "live",
      style: {
        marginLeft: "auto"
      }
    }, agent.state)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        color: "var(--text-muted)",
        lineHeight: 1.4
      }
    }, agent.desc));
  }
  function AgentConsoleScreen() {
    const [agent, setAgent] = React.useState("risk-warden");
    const [tab, setTab] = React.useState("transcript");
    const [draft, setDraft] = React.useState("");
    const [log, setLog] = React.useState([{
      author: "user",
      time: "16:02",
      text: "Why did you flag the 11:12 ES long?"
    }, {
      author: "agent",
      time: "16:02",
      conf: 0.91,
      text: "three contracts on a 0.6R setup — rule 4 caps you at one.|entry was 41s after the signal bar closed.|same pattern cost you -4.3R over the last 12 sessions."
    }, {
      author: "user",
      time: "16:04",
      text: "Draft a rule that stops it."
    }, {
      author: "agent",
      time: "16:04",
      conf: 0.77,
      text: "proposed rule 7: no entry more than 15s after signal close.|blocks 9 of your last 12 losing trades.|apply to ES and NQ only?"
    }]);
    const send = () => {
      if (!draft.trim()) return;
      setLog(l => [...l, {
        author: "user",
        time: "16:06",
        text: draft
      }, {
        author: "agent",
        time: "16:06",
        conf: 0.68,
        text: "reading 154 fills ...|drafting response"
      }]);
      setDraft("");
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 16,
        display: "flex",
        flexWrap: "wrap",
        gap: 16,
        alignItems: "flex-start",
        fontFamily: "var(--font-core)"
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Agents",
      meta: "4",
      padding: "0",
      actions: /*#__PURE__*/React.createElement(IconButton, {
        icon: "plus",
        size: "sm"
      }),
      style: {
        flex: "1 1 220px",
        minWidth: 0
      }
    }, window.EVDATA.agents.map(a => /*#__PURE__*/React.createElement(AgentRow, {
      key: a.id,
      agent: a,
      active: a.id === agent,
      onClick: () => setAgent(a.id)
    }))), /*#__PURE__*/React.createElement(Card, {
      title: agent,
      meta: "session 0x18F",
      padding: "0",
      scanlines: true,
      style: {
        flex: "4 1 380px",
        minWidth: 0
      },
      actions: /*#__PURE__*/React.createElement(Tabs, {
        variant: "segmented",
        tabs: [{
          value: "transcript",
          label: "Transcript"
        }, {
          value: "rules",
          label: "Rules"
        }],
        value: tab,
        onChange: setTab
      })
    }, tab === "transcript" ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        maxHeight: 330,
        overflow: "auto"
      }
    }, log.map((m, i) => /*#__PURE__*/React.createElement(AgentMessage, {
      key: i,
      author: m.author,
      name: m.author === "agent" ? agent : "you",
      model: m.author === "agent" ? "v2" : undefined,
      confidence: m.conf,
      time: m.time,
      streaming: m.author === "agent" && i === log.length - 1
    }, m.text.split("|").map((ln, j) => /*#__PURE__*/React.createElement(React.Fragment, {
      key: j
    }, m.author === "agent" ? "> " : "", ln, /*#__PURE__*/React.createElement("br", null)))))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        padding: 12,
        borderTop: "1px solid var(--line-hairline)",
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement(Input, {
      placeholder: "Ask the agent\u2026",
      value: draft,
      onChange: e => setDraft(e.target.value),
      style: {
        flex: 1
      },
      icon: "terminal"
    }), /*#__PURE__*/React.createElement(Button, {
      icon: "send",
      onClick: send
    }, "Send"), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "y",
      size: "sm"
    }))) : /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 12,
        display: "grid",
        gap: 8
      }
    }, [["Rule 1", "Max 2 contracts on NQ", true], ["Rule 4", "One contract below 1R expectancy", true], ["Rule 7", "No entry >15s after signal close", false]].map(([r, d, on]) => /*#__PURE__*/React.createElement("div", {
      key: r,
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "8px 10px",
        background: "var(--surface-raised)",
        border: "1px solid var(--line-hairline)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--phos-300)",
        width: 52
      }
    }, r), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "var(--text-body)",
        flex: 1
      }
    }, d), /*#__PURE__*/React.createElement(Switch, {
      size: "sm",
      checked: on
    }))))), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: "1 1 220px",
        minWidth: 0,
        display: "grid",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Confidence",
      padding: "12px"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(MeterBar, {
      label: "Signal match",
      value: 81,
      segments: 20
    }), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Data coverage",
      value: 64,
      segments: 20,
      tone: "info"
    }), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Rule risk",
      value: 9,
      max: 10,
      segments: 10,
      tone: "danger",
      showValue: true
    }))), /*#__PURE__*/React.createElement(Card, {
      title: "Permissions",
      padding: "12px"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Switch, {
      label: "Read fills",
      checked: true,
      size: "sm"
    }), /*#__PURE__*/React.createElement(Switch, {
      label: "Write journal notes",
      checked: true,
      size: "sm"
    }), /*#__PURE__*/React.createElement(Switch, {
      label: "Block orders",
      size: "sm"
    }), /*#__PURE__*/React.createElement(Switch, {
      label: "Send pad haptics",
      checked: true,
      size: "sm"
    })))));
  }
  Object.assign(window, {
    AgentConsoleScreen,
    AgentRow
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/AgentConsoleScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/AppShell.jsx
try { (() => {
(function () {
  const {
    Icon,
    IconButton,
    Badge,
    Tabs,
    GamepadKey,
    Tooltip
  } = window.EVGamePadDesignSystem_22475d;
  const NAV = [{
    id: "journal",
    label: "Journal",
    icon: "list"
  }, {
    id: "trade",
    label: "Trade",
    icon: "chart-candlestick"
  }, {
    id: "agents",
    label: "Agents",
    icon: "bot"
  }, {
    id: "pad",
    label: "Gamepad",
    icon: "gamepad-2"
  }];
  function SidebarItem({
    item,
    active,
    onClick
  }) {
    const [hover, setHover] = React.useState(false);
    return /*#__PURE__*/React.createElement("button", {
      onClick: onClick,
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        display: "flex",
        alignItems: "center",
        gap: 10,
        height: 32,
        padding: "0 12px",
        width: "100%",
        background: active ? "var(--surface-selected)" : hover ? "var(--surface-hover)" : "transparent",
        border: 0,
        borderLeft: `2px solid ${active ? "var(--phos-400)" : "transparent"}`,
        color: active ? "var(--phos-300)" : hover ? "var(--text-body)" : "var(--text-secondary)",
        fontFamily: "var(--font-core)",
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: ".12em",
        textTransform: "uppercase",
        cursor: "pointer",
        transition: "var(--transition-control)",
        textShadow: active ? "var(--glow-text)" : "none"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: item.icon,
      size: "sm"
    }), item.label);
  }
  function AppShell({
    view,
    onView,
    children
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "var(--sidebar-w) 1fr",
        height: "100%",
        background: "var(--surface-app)",
        fontFamily: "var(--font-core)",
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("aside", {
      style: {
        borderRight: "1px solid var(--line-hairline)",
        background: "var(--black-2)",
        display: "grid",
        gridTemplateRows: "var(--hud-h) 1fr auto",
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        padding: "0 12px",
        borderBottom: "1px solid var(--line-hairline)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-display)",
        fontSize: 11,
        color: "var(--phos-400)",
        textShadow: "var(--glow-text)"
      }
    }, "EV", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--arcade-red)"
      }
    }, "GAMEPAD"))), /*#__PURE__*/React.createElement("nav", {
      style: {
        padding: "8px 0",
        display: "grid",
        gap: 2,
        alignContent: "start"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "6px 12px",
        fontSize: 9,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--text-disabled)"
      }
    }, "Session"), NAV.map(n => /*#__PURE__*/React.createElement(SidebarItem, {
      key: n.id,
      item: n,
      active: view === n.id,
      onClick: () => onView(n.id)
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "14px 12px 6px",
        fontSize: 9,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--text-disabled)"
      }
    }, "Instruments"), ["NQ", "ES", "BTCUSD"].map(s => /*#__PURE__*/React.createElement("div", {
      key: s,
      style: {
        display: "flex",
        justifyContent: "space-between",
        padding: "0 12px",
        height: 26,
        alignItems: "center",
        fontSize: 11,
        color: "var(--text-muted)",
        fontFamily: "var(--font-data)"
      }
    }, /*#__PURE__*/React.createElement("span", null, s), /*#__PURE__*/React.createElement("span", {
      style: {
        color: s === "ES" ? "var(--pnl-down)" : "var(--pnl-up)"
      }
    }, s === "ES" ? "-1.10" : "+3.20", "R")))), /*#__PURE__*/React.createElement("div", {
      style: {
        borderTop: "1px solid var(--line-hairline)",
        padding: "10px 12px",
        display: "grid",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8,
        fontSize: 10,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--text-muted)"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "gamepad-2",
      size: "sm",
      style: {
        color: "var(--phos-400)"
      }
    }), "pad connected"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(GamepadKey, {
      button: "a",
      size: "sm"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "b",
      size: "sm"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "x",
      size: "sm"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "y",
      size: "sm"
    })))), /*#__PURE__*/React.createElement("main", {
      style: {
        display: "grid",
        gridTemplateRows: "var(--hud-h) 1fr 30px",
        minWidth: 0,
        minHeight: 0
      }
    }, /*#__PURE__*/React.createElement("header", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 16,
        padding: "0 16px",
        borderBottom: "1px solid var(--line-hairline)",
        background: "var(--black-2)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--text-body)"
      }
    }, "Session ", window.EVDATA.session), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        letterSpacing: ".12em",
        color: "var(--text-muted)",
        fontFamily: "var(--font-data)"
      }
    }, window.EVDATA.date), /*#__PURE__*/React.createElement(Badge, {
      tone: "live",
      dot: true
    }, "Live"), /*#__PURE__*/React.createElement(Badge, {
      tone: "agent",
      dot: true
    }, "2 agents"), /*#__PURE__*/React.createElement("div", {
      style: {
        marginLeft: "auto",
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Tooltip, {
      label: "Import fills",
      shortcut: "\u2318I"
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: "download"
    })), /*#__PURE__*/React.createElement(Tooltip, {
      label: "Notifications"
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: "bell"
    })), /*#__PURE__*/React.createElement(Tooltip, {
      label: "Settings"
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: "settings"
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: 0,
        overflow: "auto"
      }
    }, children), /*#__PURE__*/React.createElement("footer", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 16,
        padding: "0 16px",
        borderTop: "1px solid var(--line-hairline)",
        background: "var(--black-1)"
      }
    }, /*#__PURE__*/React.createElement(GamepadKey, {
      button: "a",
      size: "sm",
      label: "Log trade"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "y",
      size: "sm",
      label: "Ask agent"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "START",
      size: "sm",
      label: "Commit"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: "auto",
        fontFamily: "var(--font-terminal)",
        fontSize: 15,
        color: "var(--phos-600)"
      }
    }, "> feed ok \xB7 154 fills \xB7 lag 12ms"))));
  }
  Object.assign(window, {
    AppShell,
    SidebarItem
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/JournalScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
(function () {
  const {
    StatTile,
    Card,
    TradeRow,
    Tabs,
    Button,
    IconButton,
    MeterBar,
    AgentMessage,
    Badge,
    Tag
  } = window.EVGamePadDesignSystem_22475d;
  function EquityChart({
    series
  }) {
    let cum = 0;
    const pts = series.map(v => cum += v);
    const max = Math.max(...pts),
      min = Math.min(0, ...pts);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        height: 132,
        display: "flex",
        alignItems: "flex-end",
        gap: 3,
        padding: "8px 0",
        background: "var(--black-1)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        background: "var(--veil-grid)",
        opacity: .7,
        pointerEvents: "none"
      }
    }), pts.map((p, i) => {
      const h = Math.max(2, (p - min) / (max - min || 1) * 100);
      const up = series[i] >= 0;
      return /*#__PURE__*/React.createElement("div", {
        key: i,
        style: {
          flex: 1,
          height: `${h}%`,
          background: up ? "var(--phos-500)" : "var(--arcade-red)",
          boxShadow: up ? "0 0 6px rgba(0,255,65,.35)" : "0 0 6px rgba(232,32,42,.35)",
          position: "relative"
        }
      });
    }));
  }
  function JournalScreen({
    trades,
    selectedId,
    onSelect,
    onLog,
    range,
    onRange
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 16,
        display: "grid",
        gap: 16,
        gridTemplateColumns: "1fr 300px",
        alignItems: "start",
        fontFamily: "var(--font-core)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 16,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(StatTile, {
      label: "Net R",
      value: "+18.42R",
      delta: "+2.10R",
      tone: "up",
      icon: "trending-up"
    }), /*#__PURE__*/React.createElement(StatTile, {
      label: "Win rate",
      value: "61%",
      sub: "94 of 154 trades",
      icon: "target"
    }), /*#__PURE__*/React.createElement(StatTile, {
      label: "Avg win / loss",
      value: "1.8 : 1",
      icon: "scale"
    }), /*#__PURE__*/React.createElement(StatTile, {
      label: "Max drawdown",
      value: "-6.20R",
      tone: "down",
      icon: "trending-down"
    })), /*#__PURE__*/React.createElement(Card, {
      title: "Equity curve",
      meta: "cumulative R",
      actions: /*#__PURE__*/React.createElement(Tabs, {
        variant: "segmented",
        tabs: ["1W", "1M", "YTD"],
        value: range,
        onChange: onRange
      }),
      padding: "12px"
    }, /*#__PURE__*/React.createElement(EquityChart, {
      series: window.EVDATA.equity
    })), /*#__PURE__*/React.createElement(Card, {
      title: "Journal",
      meta: `${trades.length} trades · ${window.EVDATA.date}`,
      padding: "0",
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
        icon: "filter",
        size: "sm"
      }), /*#__PURE__*/React.createElement(IconButton, {
        icon: "download",
        size: "sm"
      }), /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        icon: "plus",
        onClick: onLog
      }, "Log trade"))
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "minmax(0,52px) minmax(0,74px) 40px minmax(0,84px) minmax(34px,1.2fr) minmax(58px,90px) 20px",
        gap: 8,
        padding: "6px 12px",
        borderBottom: "1px solid var(--line-hairline)",
        fontSize: 9,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--text-disabled)"
      }
    }, /*#__PURE__*/React.createElement("span", null, "time"), /*#__PURE__*/React.createElement("span", null, "symbol"), /*#__PURE__*/React.createElement("span", null, "side"), /*#__PURE__*/React.createElement("span", null, "price"), /*#__PURE__*/React.createElement("span", null, "tags"), /*#__PURE__*/React.createElement("span", {
      style: {
        textAlign: "right"
      }
    }, "result"), /*#__PURE__*/React.createElement("span", null)), trades.map(t => /*#__PURE__*/React.createElement(TradeRow, _extends({
      key: t.id
    }, t, {
      selected: t.id === selectedId,
      onClick: () => onSelect(t.id)
    }))))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Risk",
      padding: "12px"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(MeterBar, {
      label: "Daily risk used",
      value: 3,
      max: 5,
      segments: 10,
      tone: "warn",
      showValue: true
    }), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Drawdown limit",
      value: 4,
      max: 10,
      segments: 10,
      showValue: true
    }), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Discipline score",
      value: 82,
      segments: 20
    }))), /*#__PURE__*/React.createElement(Card, {
      title: "risk-warden",
      meta: "live",
      padding: "0",
      scanlines: true
    }, /*#__PURE__*/React.createElement(AgentMessage, {
      name: "risk-warden",
      model: "v2",
      confidence: 0.81,
      time: "16:02"
    }, "> 3 rule breaks today.", /*#__PURE__*/React.createElement("br", null), "> all three were late entries on ES.", /*#__PURE__*/React.createElement("br", null), "> suggest capping ES to 1 contract until win rate > 55%."), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "10px 12px",
        borderTop: "1px solid var(--line-hairline)",
        display: "flex",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary",
      icon: "message-square"
    }, "Open console"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost"
    }, "Dismiss"))), /*#__PURE__*/React.createElement(Card, {
      title: "Tags today",
      padding: "12px"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexWrap: "wrap",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(Tag, {
      color: "var(--arcade-cyan)"
    }, "ORB"), /*#__PURE__*/React.createElement(Tag, {
      color: "var(--arcade-cyan)"
    }, "level"), /*#__PURE__*/React.createElement(Tag, {
      color: "var(--arcade-yellow)"
    }, "fade"), /*#__PURE__*/React.createElement(Tag, {
      color: "var(--arcade-red)"
    }, "fomo"), /*#__PURE__*/React.createElement(Tag, {
      color: "var(--arcade-red)"
    }, "late"), /*#__PURE__*/React.createElement(Tag, null, "swing")))));
  }
  Object.assign(window, {
    JournalScreen,
    EquityChart
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/JournalScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/PadBindingsScreen.jsx
try { (() => {
(function () {
  const {
    Card,
    GamepadKey,
    Button,
    IconButton,
    Select,
    Switch,
    MeterBar,
    Badge,
    Dialog,
    Tooltip
  } = window.EVGamePadDesignSystem_22475d;
  function PadBindingsScreen() {
    const [rebind, setRebind] = React.useState(null);
    const [held, setHeld] = React.useState("a");
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 16,
        display: "grid",
        gridTemplateColumns: "minmax(0,1fr) minmax(0,300px)",
        gap: 16,
        alignItems: "start",
        fontFamily: "var(--font-core)",
        position: "relative"
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Bindings",
      meta: "Xbox layout \xB7 11 mapped",
      padding: "0",
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Badge, {
        tone: "live",
        dot: true
      }, "connected"), /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        variant: "secondary",
        icon: "rotate-ccw"
      }, "Reset"))
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "110px 1fr 90px 32px",
        gap: 8,
        padding: "6px 12px",
        borderBottom: "1px solid var(--line-hairline)",
        fontSize: 9,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--text-disabled)"
      }
    }, /*#__PURE__*/React.createElement("span", null, "button"), /*#__PURE__*/React.createElement("span", null, "action"), /*#__PURE__*/React.createElement("span", null, "context"), /*#__PURE__*/React.createElement("span", null)), window.EVDATA.bindings.map(b => /*#__PURE__*/React.createElement("div", {
      key: b.button,
      onMouseEnter: () => setHeld(b.button),
      style: {
        display: "grid",
        gridTemplateColumns: "110px 1fr 90px 32px",
        gap: 8,
        alignItems: "center",
        height: 36,
        padding: "0 12px",
        borderBottom: "1px solid var(--line-hairline)"
      }
    }, /*#__PURE__*/React.createElement(GamepadKey, {
      button: b.button,
      size: "sm",
      pressed: held === b.button
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "var(--text-body)"
      }
    }, b.action), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        letterSpacing: ".12em",
        textTransform: "uppercase",
        color: "var(--text-muted)"
      }
    }, b.ctx), /*#__PURE__*/React.createElement(Tooltip, {
      label: "Rebind",
      placement: "left"
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: "pencil",
      size: "sm",
      onClick: () => setRebind(b)
    }))))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Controller",
      padding: "12px"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12,
        justifyItems: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(3,22px)",
        gridTemplateRows: "repeat(3,22px)",
        gap: 2,
        justifyItems: "center",
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "up",
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "left",
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        width: 6,
        height: 6,
        background: "var(--line-strong)"
      }
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "right",
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "down",
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", null)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(3,26px)",
        gridTemplateRows: "repeat(3,26px)",
        gap: 2,
        justifyItems: "center",
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "y"
    }), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "x"
    }), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "b"
    }), /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "a",
      pressed: true
    }), /*#__PURE__*/React.createElement("span", null)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(GamepadKey, {
      button: "LB",
      size: "sm"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "LT",
      size: "sm"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "RT",
      size: "sm"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "RB",
      size: "sm"
    })))), /*#__PURE__*/React.createElement(Card, {
      title: "Feel",
      padding: "12px"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Select, {
      label: "Layout",
      options: ["Xbox", "PlayStation", "Switch Pro", "Custom"],
      size: "sm"
    }), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Stick deadzone",
      value: 12,
      max: 40,
      segments: 10,
      showValue: true
    }), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Haptic strength",
      value: 7,
      max: 10,
      segments: 10,
      tone: "info",
      showValue: true
    }), /*#__PURE__*/React.createElement(Switch, {
      label: "Rumble on rule break",
      checked: true,
      size: "sm"
    }), /*#__PURE__*/React.createElement(Switch, {
      label: "Pad-only mode",
      size: "sm"
    })))), rebind ? /*#__PURE__*/React.createElement(Dialog, {
      title: `Rebind ${rebind.button.toUpperCase()}`,
      subtitle: rebind.action,
      width: 360,
      onClose: () => setRebind(null),
      footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
        variant: "ghost",
        size: "sm",
        onClick: () => setRebind(null)
      }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        onClick: () => setRebind(null)
      }, "Assign"))
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12,
        justifyItems: "center",
        padding: "8px 0"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-terminal)",
        fontSize: 18,
        color: "var(--text-terminal)"
      }
    }, "> press any button on the pad \u2026"), /*#__PURE__*/React.createElement(GamepadKey, {
      button: rebind.button,
      size: "lg",
      pressed: true
    }))) : null);
  }
  Object.assign(window, {
    PadBindingsScreen
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/PadBindingsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/TradeDetailScreen.jsx
try { (() => {
(function () {
  const {
    Card,
    Badge,
    Tag,
    PnLValue,
    Button,
    IconButton,
    Input,
    Select,
    Checkbox,
    AgentMessage,
    MeterBar,
    GamepadKey
  } = window.EVGamePadDesignSystem_22475d;
  function TradeDetailScreen({
    trade,
    onBack
  }) {
    const t = trade || window.EVDATA.trades[0];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 16,
        display: "grid",
        gap: 16,
        fontFamily: "var(--font-core)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: "arrow-left",
      variant: "outline",
      onClick: onBack,
      label: "Back"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 20,
        fontWeight: 800,
        letterSpacing: "-.01em"
      }
    }, t.symbol), /*#__PURE__*/React.createElement(Badge, {
      tone: t.side === "short" ? "down" : "up"
    }, t.side), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-data)",
        fontSize: 12,
        color: "var(--text-muted)"
      }
    }, window.EVDATA.date, " \xB7 ", t.time), /*#__PURE__*/React.createElement("div", {
      style: {
        marginLeft: "auto",
        display: "flex",
        alignItems: "center",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(PnLValue, {
      value: t.result,
      size: "lg",
      showArrow: true
    }), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary",
      icon: "image"
    }, "Attach chart"))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "minmax(0,1fr) minmax(0,320px)",
        gap: 16,
        alignItems: "start"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 16,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Execution",
      meta: "5m",
      padding: "0"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: 240,
        position: "relative",
        background: "var(--black-1)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        background: "var(--veil-grid)",
        opacity: .8
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        left: 0,
        right: 0,
        top: "38%",
        borderTop: "1px dashed var(--phos-400)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        right: 8,
        top: -16,
        fontSize: 9,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--phos-400)"
      }
    }, "target ", t.exit || "—")), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        left: 0,
        right: 0,
        top: "62%",
        borderTop: "1px dashed var(--arcade-red)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        right: 8,
        top: -16,
        fontSize: 9,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--arcade-red)"
      }
    }, "stop")), /*#__PURE__*/React.createElement("span", {
      style: {
        position: "relative",
        fontFamily: "var(--font-terminal)",
        fontSize: 18,
        color: "var(--phos-700)",
        letterSpacing: ".1em"
      }
    }, "[ chart region \u2014 no chart asset supplied ]"))), /*#__PURE__*/React.createElement(Card, {
      title: "Journal note",
      meta: "autosaved",
      padding: "12px",
      actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Tag, {
        color: "var(--arcade-cyan)",
        onRemove: () => {}
      }, t.tags && t.tags[0] && (t.tags[0].label || t.tags[0]) || "tag"), /*#__PURE__*/React.createElement(IconButton, {
        icon: "plus",
        size: "sm"
      }))
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "var(--surface-well)",
        border: "1px solid var(--line-hairline)",
        boxShadow: "var(--inset-well)",
        padding: 10,
        fontFamily: "var(--font-core)",
        fontSize: 13,
        lineHeight: 1.5,
        color: "var(--text-body)",
        minHeight: 88
      }
    }, t.notes), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        marginTop: 10,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement(Checkbox, {
      label: "Followed plan",
      checked: t.result > 0
    }), /*#__PURE__*/React.createElement(Checkbox, {
      label: "Rule break",
      checked: t.result < 0
    }), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      style: {
        marginLeft: "auto"
      }
    }, "Save")))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Ticket",
      padding: "12px"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Entry",
      value: t.entry,
      align: "right",
      readOnly: true
    }), /*#__PURE__*/React.createElement(Input, {
      label: "Exit",
      value: t.exit || "—",
      align: "right",
      readOnly: true
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Input, {
      label: "Size",
      value: "2",
      align: "right",
      suffix: "ct",
      readOnly: true
    }), /*#__PURE__*/React.createElement(Select, {
      label: "Setup",
      options: ["ORB", "Fade", "Level", "Swing"]
    })), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Risk on this trade",
      value: 2,
      max: 5,
      segments: 10,
      showValue: true
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 6,
        marginTop: 2
      }
    }, /*#__PURE__*/React.createElement(GamepadKey, {
      button: "RT",
      size: "sm",
      label: "Size up"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "LT",
      size: "sm",
      label: "Size down"
    })))), /*#__PURE__*/React.createElement(Card, {
      title: "Agent verdict",
      padding: "0",
      scanlines: true
    }, /*#__PURE__*/React.createElement(AgentMessage, {
      name: "risk-warden",
      model: "v2",
      confidence: t.result < 0 ? 0.91 : 0.62,
      time: t.time
    }, t.result < 0 ? /*#__PURE__*/React.createElement(React.Fragment, null, "> rule 4 breach: 3 contracts on a 0.6R setup.", /*#__PURE__*/React.createElement("br", null), "> entry 41s after signal close.") : /*#__PURE__*/React.createElement(React.Fragment, null, "> sizing and timing within plan.", /*#__PURE__*/React.createElement("br", null), "> setup matches ORB-2 (0.81)."))))));
  }
  Object.assign(window, {
    TradeDetailScreen
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/TradeDetailScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/data.js
try { (() => {
window.EVDATA = {
  session: "0x18F",
  date: "28 AUG 2026",
  trades: [{
    id: 1,
    time: "09:31",
    symbol: "NQ",
    side: "long",
    entry: "18412.25",
    exit: "18461.00",
    result: 2.4,
    tags: [{
      label: "ORB",
      color: "var(--arcade-cyan)"
    }],
    notes: "Opening range break with volume. Waited for the retest, sized 2 contracts per plan."
  }, {
    id: 2,
    time: "10:04",
    symbol: "NQ",
    side: "short",
    entry: "18470.50",
    exit: "18455.75",
    result: 0.8,
    tags: [{
      label: "fade",
      color: "var(--arcade-yellow)"
    }],
    notes: "Fade into the 30m level. Took half off early."
  }, {
    id: 3,
    time: "11:12",
    symbol: "ES",
    side: "long",
    entry: "5284.25",
    exit: "5279.00",
    result: -1.1,
    tags: [{
      label: "fomo",
      color: "var(--arcade-red)"
    }, {
      label: "late",
      color: "var(--arcade-red)"
    }],
    notes: "Chased 41 seconds after the signal bar. Three contracts on a 0.6R setup."
  }, {
    id: 4,
    time: "12:26",
    symbol: "ES",
    side: "short",
    entry: "5291.00",
    exit: "5284.50",
    result: 1.3,
    tags: [{
      label: "level",
      color: "var(--arcade-cyan)"
    }],
    notes: "Clean rejection at the value area high."
  }, {
    id: 5,
    time: "13:45",
    symbol: "BTCUSD",
    side: "long",
    entry: "64120.00",
    result: 0,
    status: "open",
    tags: [{
      label: "swing"
    }],
    notes: "Swing runner. Stop under the 4h pivot."
  }],
  equity: [0.4, 1.2, -0.6, 2.4, 1.8, -1.1, 0.9, 2.2, 3.1, -0.4, 1.6, 2.4, 0.8, -1.1, 1.3, 2.0, -0.7, 1.1, 2.6, 1.4],
  agents: [{
    id: "risk-warden",
    model: "v2",
    state: "live",
    desc: "Blocks size and rule violations in real time."
  }, {
    id: "coach",
    model: "v1",
    state: "idle",
    desc: "Writes drills from your recurring mistakes."
  }, {
    id: "scribe",
    model: "v3",
    state: "live",
    desc: "Turns fills into journal entries with tags."
  }, {
    id: "quant",
    model: "beta",
    state: "off",
    desc: "Backtests tagged setups against your history."
  }],
  bindings: [{
    button: "a",
    action: "Log trade",
    ctx: "Journal"
  }, {
    button: "b",
    action: "Cancel / back",
    ctx: "Global"
  }, {
    button: "x",
    action: "Attach screenshot",
    ctx: "Trade"
  }, {
    button: "y",
    action: "Ask agent",
    ctx: "Global"
  }, {
    button: "up",
    action: "Previous trade",
    ctx: "Journal"
  }, {
    button: "down",
    action: "Next trade",
    ctx: "Journal"
  }, {
    button: "LB",
    action: "Previous day",
    ctx: "Journal"
  }, {
    button: "RB",
    action: "Next day",
    ctx: "Journal"
  }, {
    button: "RT",
    action: "Size up",
    ctx: "Ticket"
  }, {
    button: "LT",
    action: "Size down",
    ctx: "Ticket"
  }, {
    button: "START",
    action: "Commit session",
    ctx: "Global"
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/data.js", error: String((e && e.message) || e) }); }

// ui_kits/site/CodeRain.jsx
try { (() => {
(function () {
  function CodeRain({
    opacity = 0.35,
    fontSize = 14,
    speed = 90
  }) {
    const ref = React.useRef(null);
    React.useEffect(() => {
      const c = ref.current;
      if (!c) return;
      const ctx = c.getContext("2d");
      let raf,
        last = 0,
        cols = [],
        w = 0,
        h = 0;
      const glyphs = "01ｦｱｳｴｵｷｹｺｻｼｽｾｿﾀﾂﾃﾅﾆﾇﾈﾊﾋﾎﾏﾐﾑﾔﾕﾗﾘﾜNQESBTCR";
      const resize = () => {
        w = c.width = c.offsetWidth;
        h = c.height = c.offsetHeight;
        cols = Array.from({
          length: Math.ceil(w / fontSize)
        }, () => Math.random() * -40);
      };
      resize();
      window.addEventListener("resize", resize);
      const draw = t => {
        raf = requestAnimationFrame(draw);
        if (t - last < speed) return;
        last = t;
        ctx.fillStyle = "rgba(4,6,4,0.16)";
        ctx.fillRect(0, 0, w, h);
        ctx.font = fontSize + "px 'VT323', monospace";
        cols.forEach((y, i) => {
          const g = glyphs[Math.floor(Math.random() * glyphs.length)];
          ctx.fillStyle = Math.random() > 0.98 ? "#D2FFDE" : "#00A62A";
          ctx.fillText(g, i * fontSize, y * fontSize);
          cols[i] = y * fontSize > h && Math.random() > 0.975 ? 0 : y + 1;
        });
      };
      raf = requestAnimationFrame(draw);
      return () => {
        cancelAnimationFrame(raf);
        window.removeEventListener("resize", resize);
      };
    }, [fontSize, speed]);
    return /*#__PURE__*/React.createElement("canvas", {
      ref: ref,
      style: {
        position: "absolute",
        inset: 0,
        width: "100%",
        height: "100%",
        opacity,
        pointerEvents: "none"
      }
    });
  }
  Object.assign(window, {
    CodeRain
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/CodeRain.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site/LandingScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
(function () {
  const {
    Button,
    Card,
    Badge,
    StatTile,
    PnLValue,
    GamepadKey,
    Tag,
    MeterBar,
    AgentMessage,
    Icon,
    TradeRow
  } = window.EVGamePadDesignSystem_22475d;
  function Section({
    label,
    title,
    children,
    style
  }) {
    return /*#__PURE__*/React.createElement("section", {
      style: {
        padding: "56px 32px",
        borderTop: "1px solid var(--line-hairline)",
        ...style
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: "var(--max-content)",
        margin: "0 auto",
        display: "grid",
        gap: 24
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 8
      }
    }, label ? /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--phos-400)"
      }
    }, label) : null, title ? /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        fontFamily: "var(--font-core)",
        fontSize: 26,
        fontWeight: 800,
        letterSpacing: "-.01em",
        color: "var(--text-body)"
      }
    }, title) : null), children));
  }
  function LandingScreen({
    onView
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-core)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        overflow: "hidden",
        borderBottom: "1px solid var(--line-hairline)"
      }
    }, /*#__PURE__*/React.createElement(CodeRain, {
      opacity: 0.32
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        background: "var(--veil-vignette)"
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        maxWidth: "var(--max-content)",
        margin: "0 auto",
        padding: "88px 32px 72px",
        display: "grid",
        gridTemplateColumns: "1.05fr .95fr",
        gap: 40,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 20
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--phos-400)"
      }
    }, "Trading journal \xB7 AI agents \xB7 Gamepad"), /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        fontFamily: "var(--font-display)",
        fontSize: 34,
        lineHeight: 1.35,
        color: "var(--phos-100)",
        textShadow: "var(--glow-text)"
      }
    }, "JOURNAL", /*#__PURE__*/React.createElement("br", null), "LIKE IT'S", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--arcade-red)"
      }
    }, "LEVEL ONE")), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 14,
        lineHeight: 1.6,
        color: "var(--text-secondary)",
        maxWidth: "52ch"
      }
    }, "Log every fill with a thumb, not a spreadsheet. Agents read your rules, flag the breaks while the session is still open, and write the review before you close the platform."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "arcade",
      size: "lg"
    }, "Insert coin"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      size: "lg",
      iconAfter: "arrow-right",
      onClick: () => onView("pricing")
    }, "See pricing")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 16,
        alignItems: "center",
        marginTop: 4
      }
    }, /*#__PURE__*/React.createElement(GamepadKey, {
      button: "a",
      size: "sm",
      label: "Log"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "y",
      size: "sm",
      label: "Ask agent"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "START",
      size: "sm",
      label: "Commit"
    }))), /*#__PURE__*/React.createElement(Card, {
      title: "Session 0x18F",
      meta: "live",
      padding: "0",
      style: {
        boxShadow: "var(--glow-md)"
      },
      actions: /*#__PURE__*/React.createElement(Badge, {
        tone: "live",
        dot: true
      }, "NQ")
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 1,
        background: "var(--line-hairline)"
      }
    }, /*#__PURE__*/React.createElement(StatTile, {
      label: "Net R",
      value: "+18.42R",
      delta: "+2.10R",
      tone: "up",
      icon: "trending-up",
      style: {
        border: 0
      }
    }), /*#__PURE__*/React.createElement(StatTile, {
      label: "Win rate",
      value: "61%",
      sub: "94 of 154",
      icon: "target",
      style: {
        border: 0
      }
    })), window.EVDATA.trades.slice(0, 3).map(t => /*#__PURE__*/React.createElement(TradeRow, _extends({
      key: t.id
    }, t))), /*#__PURE__*/React.createElement(AgentMessage, {
      name: "risk-warden",
      model: "v2",
      confidence: 0.91,
      time: "16:02"
    }, "> rule 4 breach at 11:12 \u2014 three contracts on a 0.6R setup.")))), /*#__PURE__*/React.createElement(Section, {
      label: "Why",
      title: "Three things a spreadsheet cannot do"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(3,1fr)",
        gap: 16
      }
    }, [["gamepad-2", "Pad-first capture", "Bind log, tag, size and commit to the controller you already have on the desk. No alt-tab, no typing while price moves."], ["bot", "Agents with your rules", "Each agent holds a rule set and a job: block bad size, tag setups, draft the review. They run on the fills, not on vibes."], ["chart-candlestick", "Review that ends the day", "Discipline score, rule breaks and a written session note ready before the close bell."]].map(([ic, h, b]) => /*#__PURE__*/React.createElement(Card, {
      key: h,
      padding: "16px"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: ic,
      size: "xl",
      style: {
        color: "var(--phos-400)"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14,
        fontWeight: 700,
        color: "var(--text-body)"
      }
    }, h), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        lineHeight: 1.6,
        color: "var(--text-muted)"
      }
    }, b)))))), /*#__PURE__*/React.createElement(Section, {
      label: "Agents",
      title: "Four agents, one session",
      style: {
        background: "var(--black-2)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4,1fr)",
        gap: 12
      }
    }, window.EVDATA.agents.map(a => /*#__PURE__*/React.createElement(Card, {
      key: a.id,
      title: a.id,
      meta: a.model,
      padding: "12px",
      actions: /*#__PURE__*/React.createElement(Badge, {
        tone: a.state === "live" ? "live" : "neutral",
        dot: a.state === "live"
      }, a.state)
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        lineHeight: 1.6,
        color: "var(--text-muted)",
        minHeight: 56
      }
    }, a.desc), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Confidence",
      value: a.state === "live" ? 81 : 42,
      segments: 12,
      tone: a.state === "live" ? "phos" : "info"
    })))))), /*#__PURE__*/React.createElement(Section, {
      label: "Numbers",
      title: "From the beta cohort"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(4,1fr)",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(StatTile, {
      label: "Fills journalled",
      value: "41.2M",
      icon: "database"
    }), /*#__PURE__*/React.createElement(StatTile, {
      label: "Median review time",
      value: "4m 12s",
      delta: "-71%",
      tone: "up",
      icon: "timer"
    }), /*#__PURE__*/React.createElement(StatTile, {
      label: "Rule breaks caught",
      value: "128k",
      icon: "shield"
    }), /*#__PURE__*/React.createElement(StatTile, {
      label: "Pads supported",
      value: "17",
      icon: "gamepad-2"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        flexWrap: "wrap"
      }
    }, ["ORB", "fade", "level", "swing", "fomo", "late", "revenge", "size-up", "news"].map(t => /*#__PURE__*/React.createElement(Tag, {
      key: t,
      color: t === "fomo" || t === "late" || t === "revenge" ? "var(--arcade-red)" : "var(--arcade-cyan)"
    }, t)))), /*#__PURE__*/React.createElement(Section, {
      style: {
        textAlign: "center",
        background: "var(--black-2)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 16,
        justifyItems: "center"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-display)",
        fontSize: 20,
        color: "var(--phos-300)",
        textShadow: "var(--glow-text)"
      }
    }, "READY PLAYER ONE"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 13,
        color: "var(--text-muted)",
        maxWidth: "48ch",
        lineHeight: 1.6
      }
    }, "Bring your broker, your rules and a controller. The journal writes itself from there."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "arcade",
      size: "lg"
    }, "Insert coin"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "lg",
      iconAfter: "arrow-right"
    }, "Read the docs")))));
  }
  Object.assign(window, {
    LandingScreen,
    Section
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/LandingScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site/PricingScreen.jsx
try { (() => {
(function () {
  const {
    Button,
    Card,
    Badge,
    Tabs,
    Checkbox,
    MeterBar,
    GamepadKey,
    Icon
  } = window.EVGamePadDesignSystem_22475d;
  const PLANS = [{
    id: "rookie",
    name: "ROOKIE",
    price: "$0",
    per: "forever",
    desc: "One instrument, manual capture.",
    feats: ["1 instrument", "Manual trade log", "30-day history", "Community bindings"],
    cta: "Start free",
    variant: "secondary"
  }, {
    id: "pro",
    name: "PRO",
    price: "$29",
    per: "per month",
    desc: "Pad capture and two agents.",
    feats: ["Unlimited instruments", "Pad capture + haptics", "2 agents (risk, scribe)", "Broker import", "Full history"],
    cta: "Insert coin",
    variant: "arcade",
    featured: true
  }, {
    id: "prestige",
    name: "PRESTIGE",
    price: "$79",
    per: "per month",
    desc: "Every agent, every rule.",
    feats: ["All 4 agents", "Custom rule sets", "Backtest tagged setups", "Team review rooms", "Priority sync"],
    cta: "Talk to us",
    variant: "secondary"
  }];
  function PricingScreen() {
    const [cycle, setCycle] = React.useState("Monthly");
    return /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "var(--font-core)",
        padding: "56px 32px",
        position: "relative",
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        inset: 0,
        background: "var(--veil-grid)",
        opacity: .5,
        pointerEvents: "none"
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        maxWidth: "var(--max-content)",
        margin: "0 auto",
        display: "grid",
        gap: 28
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 10,
        justifyItems: "center",
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--phos-400)"
      }
    }, "Pricing"), /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        fontFamily: "var(--font-display)",
        fontSize: 22,
        color: "var(--phos-100)",
        textShadow: "var(--glow-text)"
      }
    }, "PICK YOUR LOADOUT"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 13,
        color: "var(--text-muted)",
        maxWidth: "46ch",
        lineHeight: 1.6
      }
    }, "Every plan includes the journal, the pad layer and unlimited screenshots. Agents are what scale."), /*#__PURE__*/React.createElement(Tabs, {
      variant: "segmented",
      tabs: ["Monthly", "Yearly"],
      value: cycle,
      onChange: setCycle,
      style: {
        marginTop: 6
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(3,1fr)",
        gap: 16,
        alignItems: "start"
      }
    }, PLANS.map(p => /*#__PURE__*/React.createElement(Card, {
      key: p.id,
      title: p.name,
      meta: p.featured ? "most picked" : undefined,
      padding: "16px",
      actions: p.featured ? /*#__PURE__*/React.createElement(Badge, {
        tone: "live"
      }, "popular") : null,
      style: p.featured ? {
        borderColor: "var(--phos-400)",
        boxShadow: "var(--glow-md)"
      } : null
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "baseline",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-data)",
        fontSize: 34,
        fontWeight: 800,
        color: "var(--text-primary)"
      }
    }, cycle === "Yearly" && p.price !== "$0" ? "$" + Math.round(parseInt(p.price.slice(1)) * 10) : p.price), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--text-muted)"
      }
    }, cycle === "Yearly" && p.price !== "$0" ? "per year" : p.per)), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "var(--text-secondary)"
      }
    }, p.desc), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 8,
        borderTop: "1px solid var(--line-hairline)",
        paddingTop: 12
      }
    }, p.feats.map(f => /*#__PURE__*/React.createElement("span", {
      key: f,
      style: {
        display: "flex",
        gap: 8,
        alignItems: "center",
        fontSize: 12,
        color: "var(--text-body)"
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "check",
      size: "sm",
      style: {
        color: "var(--phos-400)"
      }
    }), f))), /*#__PURE__*/React.createElement(Button, {
      variant: p.variant,
      fullWidth: true,
      size: "lg"
    }, p.cta))))), /*#__PURE__*/React.createElement(Card, {
      title: "Agent quotas",
      padding: "16px"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(3,1fr)",
        gap: 20
      }
    }, /*#__PURE__*/React.createElement(MeterBar, {
      label: "Rookie \xB7 reviews / month",
      value: 3,
      max: 20,
      segments: 20,
      showValue: true
    }), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Pro \xB7 reviews / month",
      value: 14,
      max: 20,
      segments: 20,
      showValue: true
    }), /*#__PURE__*/React.createElement(MeterBar, {
      label: "Prestige \xB7 unlimited",
      value: 20,
      max: 20,
      segments: 20,
      showValue: true
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 20,
        alignItems: "center",
        justifyContent: "center",
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(Checkbox, {
      label: "Bill to my prop firm"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "a",
      size: "sm",
      label: "Confirm plan"
    }), /*#__PURE__*/React.createElement(GamepadKey, {
      button: "b",
      size: "sm",
      label: "Back"
    }))));
  }
  Object.assign(window, {
    PricingScreen
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/PricingScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/site/SiteChrome.jsx
try { (() => {
(function () {
  const {
    Button,
    Icon,
    Badge
  } = window.EVGamePadDesignSystem_22475d;
  const LINKS = [{
    id: "home",
    label: "Product"
  }, {
    id: "agents",
    label: "Agents"
  }, {
    id: "pricing",
    label: "Pricing"
  }, {
    id: "docs",
    label: "Docs"
  }];
  function SiteHeader({
    view,
    onView
  }) {
    return /*#__PURE__*/React.createElement("header", {
      style: {
        position: "sticky",
        top: 0,
        zIndex: 20,
        display: "flex",
        alignItems: "center",
        gap: 28,
        height: 56,
        padding: "0 32px",
        background: "rgba(4,6,4,.86)",
        backdropFilter: "var(--blur-overlay)",
        borderBottom: "1px solid var(--line-hairline)",
        fontFamily: "var(--font-core)"
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        onView("home");
      },
      style: {
        fontFamily: "var(--font-display)",
        fontSize: 13,
        color: "var(--phos-400)",
        textShadow: "var(--glow-text)",
        textDecoration: "none"
      }
    }, "EV", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--arcade-red)"
      }
    }, "GAMEPAD")), /*#__PURE__*/React.createElement("nav", {
      style: {
        display: "flex",
        gap: 20,
        marginLeft: 8
      }
    }, LINKS.map(l => /*#__PURE__*/React.createElement("a", {
      key: l.id,
      href: "#",
      onClick: e => {
        e.preventDefault();
        onView(l.id);
      },
      style: {
        fontSize: 11,
        fontWeight: 700,
        letterSpacing: ".12em",
        textTransform: "uppercase",
        textDecoration: "none",
        color: view === l.id ? "var(--phos-300)" : "var(--text-secondary)",
        borderBottom: `1px solid ${view === l.id ? "var(--phos-400)" : "transparent"}`,
        paddingBottom: 2
      }
    }, l.label))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginLeft: "auto",
        display: "flex",
        alignItems: "center",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: "live",
      dot: true
    }, "beta"), /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      size: "sm"
    }, "Sign in"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      iconAfter: "arrow-right"
    }, "Get access")));
  }
  function SiteFooter() {
    return /*#__PURE__*/React.createElement("footer", {
      style: {
        borderTop: "1px solid var(--line-hairline)",
        padding: "32px",
        display: "grid",
        gridTemplateColumns: "2fr 1fr 1fr 1fr",
        gap: 24,
        fontFamily: "var(--font-core)",
        background: "var(--black-2)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gap: 10,
        alignContent: "start"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-display)",
        fontSize: 12,
        color: "var(--phos-400)"
      }
    }, "EV", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--arcade-red)"
      }
    }, "GAMEPAD")), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        color: "var(--text-muted)",
        maxWidth: "36ch",
        lineHeight: 1.6
      }
    }, "A trading journal you drive with a controller, reviewed by agents that know your rules."), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-terminal)",
        fontSize: 15,
        color: "var(--phos-700)"
      }
    }, "> uptime 99.98 \xB7 fills 41.2M")), [["Product", ["Journal", "Agents", "Gamepad", "Changelog"]], ["Docs", ["Quickstart", "Bindings", "API", "Imports"]], ["Company", ["About", "Careers", "Status", "Legal"]]].map(([h, items]) => /*#__PURE__*/React.createElement("div", {
      key: h,
      style: {
        display: "grid",
        gap: 8,
        alignContent: "start"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 9,
        letterSpacing: ".18em",
        textTransform: "uppercase",
        color: "var(--text-disabled)"
      }
    }, h), items.map(i => /*#__PURE__*/React.createElement("a", {
      key: i,
      href: "#",
      style: {
        fontSize: 11,
        color: "var(--text-secondary)",
        textDecoration: "none",
        letterSpacing: ".06em"
      }
    }, i)))));
  }
  Object.assign(window, {
    SiteHeader,
    SiteFooter
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/site/SiteChrome.jsx", error: String((e && e.message) || e) }); }

__ds_ns.AgentMessage = __ds_scope.AgentMessage;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.MeterBar = __ds_scope.MeterBar;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.GamepadKey = __ds_scope.GamepadKey;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.PnLValue = __ds_scope.PnLValue;

__ds_ns.TradeRow = __ds_scope.TradeRow;

})();
