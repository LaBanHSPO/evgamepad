(function(){
function CodeRain({ opacity=0.35, fontSize=14, speed=90 }) {
  const ref = React.useRef(null);
  React.useEffect(()=>{
    const c = ref.current; if(!c) return;
    const ctx = c.getContext("2d");
    let raf, last=0, cols=[], w=0, h=0;
    const glyphs = "01ｦｱｳｴｵｷｹｺｻｼｽｾｿﾀﾂﾃﾅﾆﾇﾈﾊﾋﾎﾏﾐﾑﾔﾕﾗﾘﾜNQESBTCR";
    const resize=()=>{
      w=c.width=c.offsetWidth; h=c.height=c.offsetHeight;
      cols=Array.from({length:Math.ceil(w/fontSize)},()=>Math.random()*-40);
    };
    resize(); window.addEventListener("resize",resize);
    const draw=(t)=>{
      raf=requestAnimationFrame(draw);
      if(t-last<speed) return; last=t;
      ctx.fillStyle="rgba(4,6,4,0.16)"; ctx.fillRect(0,0,w,h);
      ctx.font=fontSize+"px 'VT323', monospace";
      cols.forEach((y,i)=>{
        const g=glyphs[Math.floor(Math.random()*glyphs.length)];
        ctx.fillStyle = Math.random()>0.98 ? "#D2FFDE" : "#00A62A";
        ctx.fillText(g, i*fontSize, y*fontSize);
        cols[i] = y*fontSize > h && Math.random()>0.975 ? 0 : y+1;
      });
    };
    raf=requestAnimationFrame(draw);
    return ()=>{cancelAnimationFrame(raf); window.removeEventListener("resize",resize);};
  },[fontSize,speed]);
  return <canvas ref={ref} style={{position:"absolute",inset:0,width:"100%",height:"100%",opacity,pointerEvents:"none"}} />;
}
Object.assign(window,{CodeRain});
})();
